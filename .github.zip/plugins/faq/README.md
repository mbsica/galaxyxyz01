# FAQ (Plugin)

[![Style](https://github.styleci.io/repos/237491479/shield)](https://github.styleci.io/repos/237491479)
[![Chat](https://img.shields.io/discord/625774284823986183?color=7289da&label=Discord&logo=discord&logoColor=fff&style=flat-square)](https://azuriom.com/discord)

A FAQ plugin to make a FAQ to answer the most frequently asked questions.
