<?php

return [
    'title' => 'FAQ',

    'fields' => [
        'answer' => 'Answer',
    ],

    'empty' => 'No questions are currently available.',
];
