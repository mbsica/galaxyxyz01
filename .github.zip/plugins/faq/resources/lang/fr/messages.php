<?php

return [
    'title' => 'FAQ',

    'fields' => [
        'answer' => 'Réponse',
    ],

    'empty' => 'Aucune question n\'est actuellement disponible.',
];
