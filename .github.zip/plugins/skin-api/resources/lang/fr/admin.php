<?php

return [
    'title' => 'Configuration de l\'API Skin',

    'fields' => [
        'width' => 'Largeur',
        'height' => 'Hauteur',
        'scale' => 'Proportions max',
    ],
];
