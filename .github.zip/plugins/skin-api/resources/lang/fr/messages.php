<?php

return [
    'title' => 'Mon skin',

    'change' => 'Changer de skin',

    'skin' => 'Skin',

    'updated' => 'Votre skin a bien été changé.',
];
