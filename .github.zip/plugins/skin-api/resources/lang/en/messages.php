<?php

return [
    'title' => 'My Skin',

    'change' => 'Change your skin',

    'skin' => 'Skin',

    'updated' => 'Your skin has been updated.',
];
