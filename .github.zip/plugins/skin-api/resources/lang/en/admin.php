<?php

return [
    'title' => 'Skin API configuration',

    'fields' => [
        'width' => 'Width',
        'height' => 'Height',
        'scale' => 'Max scale',
    ],
];
