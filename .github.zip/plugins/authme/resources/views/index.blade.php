@extends('layouts.app')

@section('title', 'Plugin home')

@section('content')
    <div class="container">
        <p>This is the demo page of your plugin.</p>
    </div>
@endsection
