<?php return array (
  'advancedban' => 
  array (
    'id' => 'advancedban',
    'name' => 'AdvancedBan',
    'description' => 'A AdvancedBan plugin to let your players see your bad players!',
    'version' => '1.0.3',
    'url' => 'https://azuriom.com/market/resources/26',
    'authors' => 
    array (
      0 => 'ZeProf2Coding',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\AdvancedBan\\Providers\\AdvancedBanServiceProvider',
      1 => '\\Azuriom\\Plugin\\AdvancedBan\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 26,
    'composer' => 
    array (
      'name' => 'azuriom/advancedban',
      'type' => 'azuriom-plugin',
      'description' => 'AdvancedBan plugin for Azuriom',
      'license' => 'MIT',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\AdvancedBan\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/helpers.php',
        ),
      ),
    ),
  ),
  'authme' => 
  array (
    'id' => 'authme',
    'name' => 'AuthMe',
    'description' => 'Plugin for Azuriom',
    'version' => '1.0.0',
    'url' => 'https://azuriom.com',
    'authors' => 
    array (
      0 => 'Azuriom',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\AuthMe\\Providers\\AuthMeServiceProvider',
      1 => '\\Azuriom\\Plugin\\AuthMe\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 20,
    'composer' => 
    array (
      'name' => 'azuriom/authme',
      'type' => 'azuriom-plugin',
      'description' => 'Plugin for Azuriom',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\AuthMe\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/helpers.php',
        ),
      ),
    ),
  ),
  'faq' => 
  array (
    'id' => 'faq',
    'name' => 'FAQ',
    'description' => 'A FAQ plugin to make a FAQ to answer the most frequently asked questions.',
    'version' => '0.1.3',
    'url' => 'https://azuriom.com/market/resources/4',
    'authors' => 
    array (
      0 => 'Azuriom',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\FAQ\\Providers\\FAQServiceProvider',
      1 => '\\Azuriom\\Plugin\\FAQ\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 4,
    'composer' => 
    array (
      'name' => 'azuriom/faq',
      'type' => 'azuriom-plugin',
      'description' => 'FAQ plugin for Azuriom',
      'license' => 'MIT',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\FAQ\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/helpers.php',
        ),
      ),
    ),
  ),
  'shop' => 
  array (
    'id' => 'shop',
    'name' => 'Shop',
    'description' => 'A shop plugin to sell in-game items on your website.',
    'version' => '0.2.13',
    'url' => 'https://azuriom.com/market/resources/1',
    'authors' => 
    array (
      0 => 'Azuriom',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\Shop\\Providers\\ShopServiceProvider',
      1 => '\\Azuriom\\Plugin\\Shop\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 1,
    'composer' => 
    array (
      'name' => 'azuriom/shop',
      'type' => 'azuriom-plugin',
      'description' => 'Complete shop plugin for your server',
      'license' => 'MIT',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\Shop\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/helpers.php',
        ),
      ),
      'require' => 
      array (
        'php' => '>=7.2',
        'mollie/mollie-api-php' => '^2.12.0',
        'paymentwall/paymentwall-php' => '^2.2',
        'paygol/php-sdk' => '^1.0',
        'paypal/rest-api-sdk-php' => '^1.14.0',
        'stripe/stripe-php' => '^7.14',
        'xsolla/xsolla-sdk-php' => '^4.1',
      ),
      'replace' => 
      array (
        'guzzlehttp/guzzle' => '*',
        'psr/log' => '*',
        'symfony/http-foundation' => '*',
      ),
      'config' => 
      array (
        'optimize-autoloader' => true,
        'platform-check' => false,
      ),
    ),
  ),
  'skin-api' => 
  array (
    'id' => 'skin-api',
    'name' => 'SkinApi',
    'description' => 'Add a skin API for your Minecraft server.',
    'version' => '0.1.3',
    'url' => 'https://azuriom.com',
    'authors' => 
    array (
      0 => 'Javdu10',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\SkinApi\\Providers\\SkinApiServiceProvider',
      1 => '\\Azuriom\\Plugin\\SkinApi\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 18,
    'composer' => 
    array (
      'name' => 'azuriom/skin-api',
      'type' => 'azuriom-plugin',
      'description' => 'Plugin for Azuriom',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\SkinApi\\' => 'src/',
        ),
      ),
    ),
  ),
  'vote' => 
  array (
    'id' => 'vote',
    'name' => 'Vote',
    'description' => 'A vote plugin to reward players when they vote.',
    'version' => '0.1.14',
    'url' => 'https://azuriom.com/market/resources/2',
    'authors' => 
    array (
      0 => 'Azuriom',
    ),
    'providers' => 
    array (
      0 => '\\Azuriom\\Plugin\\Vote\\Providers\\VoteServiceProvider',
      1 => '\\Azuriom\\Plugin\\Vote\\Providers\\RouteServiceProvider',
    ),
    'apiId' => 2,
    'composer' => 
    array (
      'name' => 'azuriom/vote',
      'type' => 'azuriom-plugin',
      'description' => 'Vote plugin for Azuriom',
      'license' => 'MIT',
      'autoload' => 
      array (
        'psr-4' => 
        array (
          'Azuriom\\Plugin\\Vote\\' => 'src/',
        ),
        'files' => 
        array (
          0 => 'src/helpers.php',
        ),
      ),
    ),
  ),
);