<?php

namespace Azuriom\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class badges extends Model
{
    use HasFactory;
}
