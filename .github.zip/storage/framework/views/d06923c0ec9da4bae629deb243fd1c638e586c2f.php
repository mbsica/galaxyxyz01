<?php $__env->startSection('title', trans('admin.users.title-edit', ['user' => $user->name])); ?>

<?php $__env->startSection('content'); ?>
    <?php if($user->is_deleted): ?>
        <div class="alert alert-warning" role="alert">
            <i class="fas fa-exclamation-triangle"></i> <?php echo e(trans('admin.users.alert-deleted')); ?>

        </div>
    <?php elseif($user->isBanned()): ?>
        <div class="alert alert-warning shadow" role="alert">
            <h5><i class="fas fa-exclamation-circle"></i> <?php echo e(trans('admin.users.alert-banned.title')); ?></h5>
            <ul>
                <li><?php echo e(trans('admin.users.alert-banned.banned-by', ['author' => $user->ban->author->name])); ?></li>
                <li><?php echo e(trans('admin.users.alert-banned.reason', ['reason' => $user->ban->reason])); ?></li>
                <li><?php echo e(trans('admin.users.alert-banned.date', ['date' => format_date_compact($user->ban->created_at)])); ?></li>
            </ul>

            <form method="POST" action="<?php echo e(route('admin.users.bans.destroy', [$user, $user->ban])); ?>">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-ban"></i> <?php echo e(trans('admin.users.actions.unban')); ?>

                </button>
            </form>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.users.edit-profile')); ?></h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="nameInput"><?php echo e(trans('auth.name')); ?></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nameInput" name="name" value="<?php echo e(old('name', $user->name)); ?>" required <?php if($user->is_deleted): ?> disabled <?php endif; ?>>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group <?php if(oauth_login()): ?> d-none <?php endif; ?>">
                                    <label for="emailInput"><?php echo e(trans('auth.email')); ?></label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="emailInput" name="email" value="<?php echo e(old('email', $user->email)); ?>" required <?php if($user->is_deleted): ?> disabled <?php endif; ?>>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3 text-center">
                                <img src="<?php echo e($user->getAvatar(256)); ?>" alt="<?php echo e($user->name); ?>" class="rounded mb-3" height="150">
                            </div>
                        </div>

                        <?php if(! oauth_login()): ?>
                            <div class="form-group">
                                <label for="passwordInput"><?php echo e(trans('auth.password')); ?></label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="passwordInput" name="password" placeholder="**********" <?php if($user->is_deleted): ?> disabled <?php endif; ?>>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="roleSelect"><?php echo e(trans('messages.fields.role')); ?></label>
                            <select class="custom-select <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="roleSelect" name="role" <?php if($user->is_deleted): ?> disabled <?php endif; ?>>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>" <?php if($user->role->is($role)): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="moneyInput"><?php echo e(trans('messages.fields.money')); ?></label>
                            <div class="input-group">
                                <input type="number" min="0" max="999999999999" step="0.01" class="form-control <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="moneyInput" name="money" value="<?php echo e(old('money', $user->money)); ?>" required <?php if($user->is_deleted): ?> disabled <?php endif; ?>>

                                <div class="input-group-append">
                                    <span class="input-group-text"><?php echo e(money_name()); ?></span>
                                </div>

                                <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary" <?php if($user->is_deleted): ?> disabled <?php endif; ?>>
                            <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                        </button>

                        <?php if(! $user->is_deleted): ?>
                            <?php if(! $user->isBanned()): ?>
                                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#banModal">
                                    <i class="fas fa-ban"></i> <?php echo e(trans('admin.users.actions.ban')); ?>

                                </button>
                            <?php endif; ?>

                            <a href="<?php echo e(route('admin.users.destroy', $user)); ?>" class="btn btn-danger <?php if($user->isAdmin()): ?> disabled <?php endif; ?>" <?php if(!$user->isAdmin()): ?> data-confirm="delete" <?php endif; ?>>
                                <i class="fas fa-trash"></i> <?php echo e(trans('admin.users.actions.delete')); ?>

                            </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.users.user-info')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="registerInput"><?php echo e(trans('admin.users.fields.register-date')); ?></label>
                        <input type="text" class="form-control" id="registerInput" value="<?php echo e(format_date_compact($user->created_at)); ?>" disabled>
                    </div>

                    <?php if($user->last_login_at): ?>
                        <div class="form-group">
                            <label for="lastLoginInput"><?php echo e(trans('admin.users.fields.last-login')); ?></label>
                            <input type="text" class="form-control" id="lastLoginInput" value="<?php echo e(format_date_compact($user->last_login_at)); ?>" disabled>
                        </div>
                    <?php endif; ?>

                    <?php if(! oauth_login()): ?>
                        <form action="<?php echo e(route('admin.users.verify', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="emailVerifiedInput"><?php echo e(trans('admin.users.fields.email-verified')); ?></label>

                                <?php if($user->hasVerifiedEmail()): ?>
                                    <input type="text" class="form-control text-success" id="emailVerifiedInput" value="<?php echo e(trans('messages.yes')); ?>" disabled>
                                <?php else: ?>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control text-danger" id="emailVerifiedInput" value="<?php echo e(trans('messages.no')); ?>" disabled>

                                        <?php if(! $user->is_deleted): ?>
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-success" type="submit"><?php echo e(trans('admin.users.actions.verify-email')); ?></button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </form>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.users.2fa', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="2faInput"><?php echo e(trans('admin.users.fields.2fa')); ?></label>

                            <?php if(! $user->hasTwoFactorAuth()): ?>
                                <input type="text" class="form-control text-danger" id="2faInput" value="<?php echo e(trans('messages.no')); ?>" disabled>
                            <?php else: ?>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control text-success" id="2faInput" value="<?php echo e(trans('messages.yes')); ?>" disabled>

                                    <div class="input-group-append">
                                        <button class="btn btn-outline-danger" type="submit"><?php echo e(trans('admin.users.actions.disable-2fa')); ?></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </form>

                    <div class="form-group">
                        <label for="addressInput"><?php echo e(trans('admin.users.fields.ip')); ?></label>
                        <input type="text" class="form-control" id="addressInput" value="<?php echo e($user->last_login_ip ?? trans('messages.unknown')); ?>" disabled>
                    </div>

                    <?php if($user->game_id): ?>
                        <div class="form-group">
                            <label for="idInput"><?php echo e(game()->trans('id')); ?></label>
                            <input type="text" class="form-control" id="idInput" value="<?php echo e($user->game_id); ?>" disabled>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php if(! $user->isBanned()): ?>
        <div class="modal fade show" id="banModal" tabindex="-1" role="dialog" aria-labelledby="banLabel" aria-modal="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="banLabel"><?php echo e(trans('admin.users.ban-title', ['user' => $user->name])); ?></h2>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p><?php echo e(trans('admin.users.ban-description')); ?></p>

                        <form method="POST" action="<?php echo e(route('admin.users.bans.store', $user)); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="reasonInput"><?php echo e(trans('admin.bans.fields.reason')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="reasonInput" name="reason" required>

                                <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button class="btn btn-secondary" type="button" data-dismiss="modal"><?php echo e(trans('messages.actions.cancel')); ?></button>

                            <button class="btn btn-danger" type="submit">
                                <i class="fas fa-ban"></i> <?php echo e(trans('admin.users.actions.ban')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if(! $logs->isEmpty()): ?>
        <div class="card shadow mb-4">
            <div class="card-header">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.logs.title')); ?></h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                            <th scope="col"><?php echo e(trans('messages.fields.date')); ?></th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($log->id); ?></th>
                                <td>
                                    <i class="text-<?php echo e($log->getActionFormat()['color']); ?> fas fa-<?php echo e($log->getActionFormat()['icon']); ?>"></i>
                                    <?php echo e($log->getActionMessage()); ?>

                                </td>
                                <td><?php echo e(format_date_compact($log->created_at)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

                <?php echo e($logs->links()); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>