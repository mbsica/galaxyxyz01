
<div class="modal-dialog" style="max-width: 800px" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h6 class="modal-title" id="itemModalLabel"><?php echo e($package->name); ?></h3>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="news-box">
                <div class="box-each" style="border-left: 0; text-align: center;">
                    <?php if($package->image !== null): ?>
                        <img  src="<?php echo e($package->imageUrl()); ?>" alt="<?php echo e($package->name); ?>">
                    <?php endif; ?>
                    <h4 class="pt-3"><?php echo e($package->name); ?></h4>
                   
                    <h6 class="pt-2 pb-2">
                        <?php if($package->isDiscounted()): ?>
                            <del class="small" style="color: red; font-size: 75%"><?php echo e($package->getOriginalPrice()); ?></del>
                        <?php endif; ?>
                        <?php echo e(shop_format_amount($package->getPrice())); ?>

                    </h6>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if($package->isInCart()): ?>
                            <form action="<?php echo e(route('shop.cart.remove', $package)); ?>" method="POST" class="form-inline">
                                <?php echo csrf_field(); ?>

                                <button type="submit" class="btn btn-danger w-100 ml-5 mr-5">
                                    <?php echo e(trans('shop::messages.actions.remove')); ?>

                                </button>
                            </form>
                        <?php elseif($package->getMaxQuantity() < 1): ?>
                            <?php echo e(trans('shop::messages.packages.limit')); ?>

                        <?php elseif(! $package->hasBoughtRequirements()): ?>
                            <?php echo e(trans('shop::messages.packages.requirements')); ?>

                        <?php else: ?>
                            <form action="<?php echo e(route('shop.packages.buy', $package)); ?>" method="POST" class="form-inline">
                                <?php echo csrf_field(); ?>

                                <?php if($package->has_quantity): ?>
                                    <div class="form-group">
                                        <label for="quantity"><?php echo e(trans('shop::messages.fields.quantity')); ?></label>
                                    </div>

                                    <div class="form-group mx-3">
                                        <input type="number" min="0" max="<?php echo e($package->getMaxQuantity()); ?>" size="5" class="form-control" name="quantity" id="quantity" value="1">
                                    </div>
                                <?php endif; ?>

                                <button type="submit" class="btn btn-success w-100 ml-5 mr-5" style="font-size: 12px;">
                                    <?php echo e(trans('shop::messages.buy')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="alert" role="alert">
                            <?php echo e(trans('shop::messages.cart.guest')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="box-list">
                    <div class="nano">
                        <div id="defaultOpen" class="nano-content">
                            <div class="package-body2 pt-1 pb-1">
                                <?php echo $package->description; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <span class="flex-md-fill font-weight-bold">
            </span>
            <button class="btn btn-secondary" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">Хаах</span>
            </button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/packages/show.blade.php ENDPATH**/ ?>