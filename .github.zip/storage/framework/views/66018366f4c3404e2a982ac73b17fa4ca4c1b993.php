

<?php $__env->startSection('title', trans('shop::admin.coupons.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.code')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.discount')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.enabled')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::admin.coupons.active')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($coupon->id); ?></th>
                            <td><?php echo e($coupon->code); ?></td>
                            <td><?php echo e($coupon->discount); ?> %</td>
                            <td>
                                <span class="badge badge-<?php echo e($coupon->is_enabled ? 'success' : 'danger'); ?>">
                                    <?php echo e(trans_bool($coupon->is_enabled)); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo e($coupon->isActive() ? 'success' : 'danger'); ?>">
                                    <?php echo e(trans_bool($coupon->isActive())); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('shop.admin.coupons.edit', $coupon)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('shop.admin.coupons.destroy', $coupon)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <a class="btn btn-primary" href="<?php echo e(route('shop.admin.coupons.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/coupons/index.blade.php ENDPATH**/ ?>