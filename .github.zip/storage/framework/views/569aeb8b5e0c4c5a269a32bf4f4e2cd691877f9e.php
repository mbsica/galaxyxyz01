

<?php $__env->startSection('title', 'Staffs'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('elements.serverinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="h4 deco-h pt-3 pb-3"><span> <span class="text-red">Players</span> List</span></div>

<div class="row">
    <div class="col-md-3">
        <div class="card">
            <div class="card-header d-flex">
                <div class="before-icon"><i class="fas fa-users"></i></div>
                <div class="p3">Members</div>
            </div>
            <ul class="list-group">
                <a href="players"><li class="list-group-item">All Players <span class="badge badge-secondary"><?php echo e($players->count()); ?></span></li></a>
                <a href="staffs"><li class="list-group-item">Staffs <span class="badge badge-secondary">5</span></li></a>
                <a href="#"><li class="list-group-item">Leaders <span class="badge badge-secondary">3</span></li></a>
            </ul>
        </div>
    </div>
    <div class="col-md-9">
        <div class="card">
            <div class="card-header">Эзэд</div>
            <div class="card-body">
                <div class="d-flex">
                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex staff-listmember">
                            <img class="member-icon pr-2" src="<?php echo e($owner->getAvatar()); ?>" alt="">
                            <div class="pl-2" style="margin-top: -5px">
                                <a href="#"><?php echo e($owner->name); ?></a>
                                <span class="d-block" style="margin-top: -10px"><?php echo e($owner->role->name); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="h-15"></div>
        <div class="card">
            <div class="card-header">Хөгжүүлэгчид</div>
            <div class="card-body">
                <div class="d-flex">
                    <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex staff-listmember">
                            <img class="member-icon pr-2" src="<?php echo e($developer->getAvatar()); ?>" alt="">
                            <div class="pl-2" style="margin-top: -5px">
                                <a href="#"><?php echo e($developer->name); ?></a>
                                <span class="d-block" style="margin-top: -10px"><?php echo e($developer->role->name); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="h-15"></div>
        <div class="card">
            <div class="card-header">Ахлах модераторууд</div>
            <div class="card-body">
                <div class="d-flex">
                    <?php $__currentLoopData = $srmods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srmod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex staff-listmember">
                            <img class="member-icon pr-2" src="<?php echo e($srmod->getAvatar()); ?>" alt="">
                            <div class="pl-2" style="margin-top: -5px">
                                <a href="#"><?php echo e($srmod->name); ?></a>
                                <span class="d-block" style="margin-top: -10px"><?php echo e($srmod->role->name); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="h-15"></div>
        <div class="card">
            <div class="card-header">Модераторууд</div>
            <div class="card-body">
                <div class="d-flex">
                    <?php $__currentLoopData = $mods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex staff-listmember">
                            <img class="member-icon pr-2" src="<?php echo e($mod->getAvatar()); ?>" alt="">
                            <div class="pl-2" style="margin-top: -5px">
                                <a href="#"><?php echo e($mod->name); ?></a>
                                <span class="d-block" style="margin-top: -10px"><?php echo e($mod->role->name); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="h-15"></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/profile/staff.blade.php ENDPATH**/ ?>