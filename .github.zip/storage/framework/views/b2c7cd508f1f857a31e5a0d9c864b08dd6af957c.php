<?php $__env->startSection('title', trans('admin.settings.maintenance.title')); ?>

<?php echo $__env->make('admin.elements.editor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.settings.maintenance.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="enableSwitch" name="maintenance-status" <?php if(setting('maintenance-status', false)): ?> checked <?php endif; ?>>
                    <label class="custom-control-label" for="enableSwitch"><?php echo e(trans('admin.settings.maintenance.enable')); ?></label>
                </div>

                <div class="form-group">
                    <label for="maintenanceArea"><?php echo e(trans('admin.settings.maintenance.message')); ?></label>
                    <textarea class="form-control html-editor <?php $__errorArgs = ['maintenance-message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="maintenanceArea" name="maintenance-message" rows="5"><?php echo e(old('maintenance-message', setting('maintenance-message'))); ?></textarea>

                    <?php $__errorArgs = ['maintenance-message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/settings/maintenance.blade.php ENDPATH**/ ?>