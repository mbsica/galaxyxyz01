<?php $__env->startSection('title', trans('admin.logs.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.user')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.date')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($log->id); ?></th>
                            <td><?php echo e($log->user->name); ?></td>
                            <td>
                                <i class="text-<?php echo e($log->getActionFormat()['color']); ?> fas fa-<?php echo e($log->getActionFormat()['icon']); ?>"></i>
                                <?php echo e($log->getActionMessage()); ?>

                            </td>
                            <td><?php echo e(format_date_compact($log->created_at)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <?php echo e($logs->links()); ?>


            <form action="<?php echo e(route('admin.logs.clear')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash"></i> <?php echo e(trans('admin.logs.actions.clear')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/logs/index.blade.php ENDPATH**/ ?>