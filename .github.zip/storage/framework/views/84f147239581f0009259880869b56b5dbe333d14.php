

<?php $__env->startSection('title', trans('faq::admin.questions.title')); ?>

<?php if(Auth::user()->isAdmin()): ?>
    <?php $__env->startPush('footer-scripts'); ?>
        <script src="<?php echo e(asset('vendor/sortablejs/Sortable.min.js')); ?>"></script>
        <script>
            const sortable = Sortable.create(document.getElementById('questions'), {
                animation: 150,
                group: 'question',
                handle: '.sortable-handle'
            });

            function serialize(sortable) {
                const serialized = [];

                [].slice.call(sortable.children).forEach(function (child) {
                    serialized.push(child.dataset['id']);
                });

                return serialized
            }

            const saveButton = document.getElementById('save');
            const saveButtonIcon = saveButton.querySelector('.btn-spinner');

            saveButton.addEventListener('click', function () {
                saveButton.setAttribute('disabled', '');
                saveButtonIcon.classList.remove('d-none');

                axios.post('<?php echo e(route('faq.admin.questions.update-order')); ?>', {
                    'questions': serialize(sortable.el),
                }).then(function (json) {
                    createAlert('success', json.data.message, true);
                }).catch(function (error) {
                    createAlert('danger', error.response.data.message ? error.response.data.message : error, true)
                }).finally(function () {
                    saveButton.removeAttribute('disabled');
                    saveButtonIcon.classList.add('d-none');
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <?php if(empty($questions)): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle"></i>
                    <?php echo e(trans('faq::messages.empty')); ?>

                </div>
            <?php else: ?>
                <ol class="list-unstyled sortable mb-3" id="questions">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="sortable-item sortable-dropdown" data-id="<?php echo e($question->id); ?>">
                            <div class="card">
                                <div class="card-body d-flex justify-content-between">
                                <span>
                                    <i class="fas fa-arrows-alt sortable-handle"></i>

                                    <span><?php echo e($question->name); ?></span>
                                </span>
                                    <span>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $question)): ?>
                                            <a href="<?php echo e(route('faq.admin.questions.edit', $question)); ?>" class="m-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $question)): ?>
                                            <a href="<?php echo e(route('faq.admin.questions.destroy', $question)); ?>" class="m-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                                        <?php endif; ?>
                                </span>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>

                <button type="button" class="btn btn-success" id="save">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                    <span class="spinner-border spinner-border-sm btn-spinner d-none" role="status"></span>
                </button>
            <?php endif; ?>

            <a class="btn btn-primary" href="<?php echo e(route('faq.admin.questions.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/faq/resources/views/admin/questions/index.blade.php ENDPATH**/ ?>