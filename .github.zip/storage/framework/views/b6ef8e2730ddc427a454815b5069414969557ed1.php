<div class="mn-contact-top">
    <div class="container">
        <div class="float-left">
            <ul class="mn-social-link">
                <li><a href="#"><i class="fab fa-twitch"></i></a></li>
                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="#"><i class="fab fa-discord"></i></a></li>
            </ul>
        </div>
        <div class="float-right">
            <ul class="mn-social-link">
                <li><a href="#">About</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Service</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
    </div>
</div>

<!-------------Nav Menu ------------------->
<nav class="navbar sticky-top navbar-expand-md mn-navbar">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon">
                <i class="fas fa-bars fa-iconscolor"></i>
            </span>
        </button>
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img class="logo" src=" <?php echo e(site_logo()); ?>" alt="">
        </a>
      
        <div class="collapse navbar-collapse" id="navbarTogglerDemo03" style="margin-right: -5px">
            <ul class="navbar-nav">
                <?php $__currentLoopData = $navbar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$element->isDropdown()): ?>
                        <li class="nav-item <?php if($element->isCurrent()): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e($element->getLink()); ?>" <?php if($element->new_tab): ?> target="_blank" rel="noopener noreferrer" <?php endif; ?>><?php echo e($element->name); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="topdropdown nav-item dropdown <?php if($element->isCurrent()): ?> active <?php endif; ?>">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown<?php echo e($element->id); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e($element->name); ?>

                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown<?php echo e($element->id); ?>">
                                <?php $__currentLoopData = $element->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item <?php if($childElement->isCurrent()): ?> active <?php endif; ?>" href="<?php echo e($childElement->getLink()); ?>" <?php if($childElement->new_tab): ?> target="_blank" rel="noopener noreferrer" <?php endif; ?>><?php echo e($childElement->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/galaowmw/galaxy/resources/views/elements/navbar.blade.php ENDPATH**/ ?>