<?php if(setting('captcha.type') === 'recaptcha'): ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="https://www.google.com/recaptcha/api.js?hl=<?php echo e(app()->getLocale()); ?>" async defer></script>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('footer-scripts'); ?>
        <script>
            const captchaForm = document.getElementById('captcha-form');

            function submitCaptchaForm() {
                captchaForm.submit();
            }

            if (captchaForm) {
                captchaForm.addEventListener('submit', function (e) {
                    e.preventDefault();

                    grecaptcha.execute();
                });
            }
        </script>
    <?php $__env->stopPush(); ?>

    <div class="g-recaptcha" data-sitekey="<?php echo e(setting('captcha.site_key')); ?>" data-callback="submitCaptchaForm" data-size="invisible"></div>

<?php elseif(setting('captcha.type') === 'hcaptcha'): ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="https://hcaptcha.com/1/api.js?hl=<?php echo e(app()->getLocale()); ?>" async defer></script>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('footer-scripts'); ?>
        <script>
            const captchaForm = document.getElementById('captcha-form');

            if (captchaForm) {
                captchaForm.addEventListener('submit', function (e) {
                    const hCaptchaInput = captchaForm.querySelector('[name="h-captcha-response"]');

                    if (hCaptchaInput && hCaptchaInput.value === '') {
                        e.preventDefault();

                        hcaptcha.execute();
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>

    <div class="h-captcha mb-2 <?php if($center ?? false): ?> text-center <?php endif; ?>" data-sitekey="<?php echo e(setting('captcha.site_key')); ?>" <?php if($dark ?? false): ?> data-theme="dark" <?php endif; ?>></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/elements/captcha.blade.php ENDPATH**/ ?>