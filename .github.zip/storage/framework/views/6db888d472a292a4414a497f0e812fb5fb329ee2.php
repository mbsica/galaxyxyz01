<?php $__env->startSection('title', trans('admin.settings.seo.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.settings.seo.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="htmlHeadArea"><?php echo e(trans('admin.settings.seo.html-head-code')); ?></label>
                    <textarea class="form-control <?php $__errorArgs = ['html-head'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="htmlHeadArea" name="html-head" rows="4"><?php echo e(old('html-head', $htmlHead)); ?></textarea>

                    <?php $__errorArgs = ['html-head'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="htmlBodyArea"><?php echo e(trans('admin.settings.seo.html-body-code')); ?></label>
                    <textarea class="form-control <?php $__errorArgs = ['html-body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="htmlBodyArea" name="html-body" aria-describedby="htmlBodyInfo" rows="4"><?php echo e(old('html-body', $htmlBody)); ?></textarea>

                    <?php $__errorArgs = ['html-body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <small id="htmlBodyInfo" class="form-text"><?php echo e(trans('admin.settings.seo.html-code-info')); ?></small>
                </div>

                <div class="form-group custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="welcomePopupSwitch" name="enable_welcome_popup" data-toggle="collapse" data-target="#welcomePopup" <?php if($welcomePopup): ?> checked <?php endif; ?>>
                    <label class="custom-control-label" for="welcomePopupSwitch"><?php echo e(trans('admin.settings.seo.welcome-popup.enable')); ?></label>
                </div>

                <div id="welcomePopup" class="<?php echo e($welcomePopup ? 'show' : 'collapse'); ?>">
                    <div class="card card-body mb-3">
                        <div class="form-group mb-0">
                            <label for="welcomePopupArea"><?php echo e(trans('admin.settings.seo.welcome-popup.message')); ?></label>
                            <textarea class="form-control <?php $__errorArgs = ['welcome-popup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="welcomePopupArea" name="welcome-popup" aria-describedby="welcomePopupInfo" rows="5"><?php echo e(old('welcome-popup', $welcomePopup)); ?></textarea>

                            <?php $__errorArgs = ['welcome-popup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <small id="welcomePopupInfo" class="form-text"><?php echo e(trans('admin.settings.seo.welcome-popup.info')); ?></small>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/settings/seo.blade.php ENDPATH**/ ?>