<?php $__env->startSection('title', trans('admin.posts.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.title')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.image')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.slug')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.author')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.date')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e($post->id); ?>

                                <?php if($post->is_pinned): ?>
                                    <i class="fas fa-thumbtack text-primary rotate-45" title="<?php echo e(trans('admin.posts.info.pinned')); ?>" data-toggle="tooltip"></i>
                                <?php endif; ?>
                            </th>
                            <td><?php echo e($post->title); ?></td>
                            <td>
                                <?php if($post->image !== null): ?>
                                    <img src="<?php echo e($post->imageUrl()); ?>" class="img-small rounded" alt="<?php echo e($post->title); ?>">
                                <?php endif; ?>
                            </td>
                            <td><a href="<?php echo e(route('posts.show', $post)); ?>"><?php echo e($post->slug); ?></a></td>
                            <td>
                                <a href="<?php echo e(route('admin.users.edit', $post->author )); ?>"><?php echo e($post->author->name); ?></a>
                            </td>
                            <td><?php echo e(format_date($post->published_at)); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.posts.destroy', $post)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <?php echo e($posts->links()); ?>


            <a class="btn btn-primary" href="<?php echo e(route('admin.posts.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/posts/index.blade.php ENDPATH**/ ?>