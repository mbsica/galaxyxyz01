

<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        document.querySelectorAll('[data-package-url]').forEach(function (el) {
            el.addEventListener('click', function (ev) {
                ev.preventDefault();

                axios.get(el.dataset['packageUrl'], {
                    headers: {
                        'X-PJAX': 'true'
                    }
                }).then(function (response) {
                    $('#itemModal').html(response.data).modal('show');
                }).catch(function (error) {
                    createAlert('danger', error, true);
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('elements.serverinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container content pl-0 pr-0">
        <div style="height: 15px;"></div>
        <div class="card">
            <div class="card-body pt-3 pb-3">
                <?php if(auth()->guard()->check()): ?>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="d-flex">
                                <i class="fas fa-shopping-cart" style="margin: auto 20px auto 0; font-size:32px; color:#fff;"></i>
                                <a href="/galaxy/shop/cart">
                                    <div class="pl-2">
                                        <h6 class="text-red">Сагс</h6>
                                        <p class="small p-0 m-0">Сагсруу очих</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-8 shopCat-right"><?php echo e($category->name); ?></div>
                    </div>
                <?php else: ?> 
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="d-flex">
                                <i class="fas fa-shopping-cart" style="margin: auto 20px auto 0; font-size:32px; color:#fff;"></i>
                                <a href="">
                                    <div class="pl-2">
                                        <h6 class="text-red">WELLCOME</h6>
                                        <p class="small p-0 m-0">Нэвтрээгүй байна.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-8 shopCat-right"><?php echo e($category->name); ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div style="height: 15px;"></div>
        <div class="row">
            <div class="col-md-4 pb-4">
                <?php echo $__env->make('shop::categories.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-md-8">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $category->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-4 mb-4">
                            <div class="card h-100">
                                <div class="card-body">
                                    <?php if($package->image !== null): ?>
                                        <a href="#" data-package-url="<?php echo e(route('shop.packages.show', $package)); ?>">
                                            <img class="card-img-top" src="<?php echo e($package->imageUrl()); ?>" alt="<?php echo e($package->name); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Tooltip on top">
                                        </a>
                                    <?php endif; ?>
                                    <h6 class="text-center"><?php echo e($package->name); ?></h6>
                                    <p class="text-center">
                                        <?php if($package->isDiscounted()): ?>
                                            <del class="small" style="color: red; font-size: 65%"><?php echo e($package->getOriginalPrice()); ?></del>
                                        <?php endif; ?>
                                        <?php echo e(shop_format_amount($package->getPrice())); ?>

                                    </p>
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-warning mr-2" data-package-url="<?php echo e(route('shop.packages.show', $package)); ?>">
                                            <i class="fas fa-info"></i>
                                        </button>

                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if($package->isInCart()): ?>
                                                <form action="<?php echo e(route('shop.cart.remove', $package)); ?>" method="POST" class="form-inline">
                                                    <?php echo csrf_field(); ?>

                                                    <button type="submit" class="btn btn-danger ">
                                                        <?php echo e(trans('shop::messages.actions.remove')); ?>

                                                    </button>
                                                </form>
                                            <?php elseif($package->getMaxQuantity() < 1): ?>
                                                <?php echo e(trans('shop::messages.packages.limit')); ?>

                                            <?php elseif(! $package->hasBoughtRequirements()): ?>
                                                <?php echo e(trans('shop::messages.packages.requirements')); ?>

                                            <?php else: ?>
                                                <form action="<?php echo e(route('shop.packages.buy', $package)); ?>" method="POST" class="d-flex">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-success" style="font-size: 12px;">
                                                        <?php echo e(trans('shop::messages.buy')); ?>

                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <button type="submit" class="btn btn-success" style="font-size: 12px;" data-toggle="modal" data-target=".bd-example-modal-lg">
                                                <?php echo e(trans('shop::messages.buy')); ?>

                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col">
                            <div class="alert alert-warning" role="alert">
                                <?php echo e(trans('shop::messages.categories.empty')); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="itemModal" tabindex="-1" role="dialog" aria-labelledby="itemModalLabel" aria-hidden="true"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/plugins/shop/resources/views/categories/show.blade.php ENDPATH**/ ?>