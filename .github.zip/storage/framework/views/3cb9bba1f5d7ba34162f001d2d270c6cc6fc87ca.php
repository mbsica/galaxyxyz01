<?php $__env->startPush('footer-scripts'); ?>
    <script>
      function addCommandListener(el) {
        el.addEventListener('click', function () {
          const element = el.parentNode.parentNode;

          element.parentNode.removeChild(element);
        });
      }

      document.querySelectorAll('.command-remove').forEach(function (el) {
        addCommandListener(el);
      });

      document.getElementById('addCommandButton').addEventListener('click', function () {
        let input = '<div class="input-group mb-2"><input type="text" name="commands[]" class="form-control"><div class="input-group-append">';
        input += '<button class="btn btn-outline-danger command-remove" type="button"><i class="fas fa-times"></i></button>';
        input += '</div></div>';

        const newElement = document.createElement('div');
        newElement.innerHTML = input;

        addCommandListener(newElement.querySelector('.command-remove'));

        document.getElementById('commands').appendChild(newElement);
      });
    </script>
<?php $__env->stopPush(); ?>

<div id="commands">

    <?php $__empty_1 = true; $__currentLoopData = $commands ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $command): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="input-group mb-2">
            <input type="text" class="form-control" name="commands[]" value="<?php echo e($command); ?>">
            <div class="input-group-append">
                <button class="btn btn-outline-danger command-remove" type="button"><i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="input-group mb-2">
            <input type="text" class="form-control" name="commands[]">
            <div class="input-group-append">
                <button class="btn btn-outline-danger command-remove" type="button"><i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    <?php endif; ?>
</div>

<small class="form-text"><?php echo app('translator')->get('vote::admin.rewards.commands-info'); ?></small>

<div class="my-1">
    <button type="button" id="addCommandButton" class="btn btn-sm btn-success">
        <i class="fas fa-plus"></i>
        <?php echo e(trans('messages.actions.add')); ?>

    </button>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\plugins/vote/resources/views/admin/elements/commands.blade.php ENDPATH**/ ?>