

<?php $__env->startSection('title', trans('shop::admin.packages.title-create')); ?>

<?php echo $__env->make('admin.elements.editor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('shop.admin.packages.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo $__env->make('shop::admin.packages._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/plugins/shop/resources/views/admin/packages/create.blade.php ENDPATH**/ ?>