<!DOCTYPE html>
<?php echo $__env->make('elements.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $__env->yieldContent('description', setting('description', '')); ?>">
    <meta name="theme-color" content="#3490DC">
    <meta name="author" content="Azuriom">

    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:type" content="<?php echo $__env->yieldContent('type', 'website'); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo e(favicon()); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('description', setting('description', '')); ?>">
    <meta property="og:site_name" content="<?php echo e(site_name()); ?>">
    <?php echo $__env->yieldPushContent('meta'); ?>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(site_name()); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(favicon()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>" defer></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/axios/axios.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/script.js')); ?>" defer></script>
    

    <script>
        function horizonTab(det, tabId) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for(i=0; i<tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks=document.getElementsByClassName("tablinks");
            for(i=0; i<tablinks.length; i++){
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabId).style.display = "block";
            det.currentTarget.className += " active";
        }
    </script>

    <!-- Page level scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/galaxy.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>   
    <?php echo $__env->make('elements.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <div class="container">
            <?php echo $__env->make('elements.session-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <img class="bg-topImage" src="<?php echo e(URL::asset('public/assets/img/bg-top.png')); ?>" alt="">
    <img class="bg-bottomImage" src="<?php echo e(URL::asset('public/assets/img/bg-bottom.png')); ?>" alt="">

    <footer>
        <?php echo $__env->make('elements.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
    <?php echo $__env->make('elements.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('footer-scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/layouts/app.blade.php ENDPATH**/ ?>