<?php $__env->startSection('title', trans('messages.home')); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('elements.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('elements.serverinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="height: 30px"></div> 
    <div class="h3 deco-h"><span> <span class="text-red">latest</span> news</span></div>
    <div style="height: 30px"></div> 
    <div class="news-box">
        <div class="box-list">
            <div class="nano">
                <div id="defaultOpen" class="nano-content">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="box-item tablinks" onclick="horizonTab(event, 'tab-<?php echo e($post->id); ?>')">
                            <div class="box-itemImage">
                                <?php if($post->hasImage()): ?>
                                    <img src="<?php echo e($post->imageUrl()); ?>" alt="<?php echo e($post->title); ?>">
                                <?php endif; ?>
                            </div>
                            <h6 class="box-itemTitle"><?php echo e(Str::limit(strip_tags($post->title), 55)); ?></h6>
                            <p class="box-itemContent"><?php echo e(Str::limit(strip_tags($post->content), 55)); ?></p>
                            <div class="box-itemDate">
                                <i class="fas fa-calendar-alt"></i> <?php echo e(date('d-m-Y', strtotime($post->published_at))); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="box-each">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="tab-<?php echo e($post->id); ?>" class="nano tab-content">
                    <div class="nano-content">
                        <div class="box-itemImage">
                            <?php if($post->hasImage()): ?>
                                <img src="<?php echo e($post->imageUrl()); ?>" alt="<?php echo e($post->title); ?>">
                            <?php endif; ?>
                            <span class="item-category">
                                <p>bsdkjakd</p>
                            </span>
                        </div>
                        <h4><?php echo e(Str::limit(strip_tags($post->title), 55)); ?></h4>
                            <p><?php echo e(Str::limit(strip_tags($post->content), 150)); ?></p>
                            <a href="<?php echo e(route('posts.show', $post)); ?>">READMMORE</a>
                        <div class="date"><i class="fas fa-calendar-alt"></i> <?php echo e(date('d-m-Y', strtotime($post->published_at))); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div style="height: 30px"></div>
    <div class="container">
        <div class="row">
            <div class="main-content col-lg-8">
                <div class="h4 deco-h"><span>Most viewed</span></div>
                <div style="height: 30px"></div>
                <div class="row">
                    <?php $__currentLoopData = $mostvieweds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostviewed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="blog-box">
                                <a href="<?php echo e(route('posts.show', $mostviewed)); ?>" class="post-image">
                                    <?php if($post->hasImage()): ?>
                                        <img src="<?php echo e($mostviewed->imageUrl()); ?>" alt="<?php echo e($mostviewed->title); ?>">
                                    <?php endif; ?>
                                    <span class="comment-count" style="color: #494949;">
                                        <?php echo e($mostviewed->comments->count()); ?>

                                    </span>
                                </a>
                                <div class="gap"></div>
                                <h6>
                                    <?php echo e(Str::limit(strip_tags($mostviewed->title), 55)); ?>

                                </h6>
                                <div class="postby">
                                    <img src="<?php echo e($post->author->getAvatar()); ?>" alt="" class="rounded-circle">
                                </div>
                                <div class="gap"></div>
                                <div class="post-text">
                                    <p><?php echo e(Str::limit(strip_tags($mostviewed->content), 150)); ?></p>
                                </div>
                                <div class="gap"></div>
                                <button type="button" class="btn btn-secondary readmore" href="<?php echo e(route('posts.show', $mostviewed)); ?>">READMORE</button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="right-widget col-lg-4">
                <?php echo $__env->make('elements.widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
   
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .home-background {
            height: 500px;
        }

        .discord-widget {
            border: none;
            width: 100%;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/home.blade.php ENDPATH**/ ?>