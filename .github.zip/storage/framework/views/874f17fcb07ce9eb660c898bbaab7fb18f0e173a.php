

<?php $__env->startSection('title', trans('advancedban::messages.title')); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('elements.serverinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="height: 15px;"></div>
<div class="h3 deco-h"><span> <span class="text-red">Server</span> bans</span></div>
<div style="height: 15px"></div>
		<div class="table-wrapper table-responsive">
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th scope="col"><?php echo e(trans('messages.fields.type')); ?></th>
						<th scope="col"><?php echo e(trans('advancedban::messages.username')); ?></th>
						<th scope="col"><?php echo e(trans('advancedban::messages.reason')); ?></th>
						<th scope="col"><?php echo e(trans('advancedban::messages.staff')); ?></th>
						<th scope="col"><?php echo e(trans('messages.fields.date')); ?></th>
						<th scope="col"><?php echo e(trans('advancedban::messages.expires_at')); ?></th>
						<th scope="col" class="text-right"><?php echo e(trans('messages.fields.status')); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = array_map('json_decode', array_unique(array_map('json_encode',
						array_merge($PunishmentHistory, $Punishments)
						))); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punishment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr class="text-nowrap">
							<td><?php echo e($punishment->punishmentType); ?></td>
							<td><img src="https://crafatar.com/avatars/<?php echo e($punishment->uuid); ?>?size=30&default=MHF_Steve"> <?php echo e($punishment->name); ?></td>
							<td><?php echo e($punishment->reason); ?></td>
							<td><img data-name="<?php echo e($punishment->operator); ?>" src="https://crafatar.com/avatars/8667ba71-b85a-4004-af54-457a9734eed7?size=30"> <?php echo e($punishment->operator); ?></td>
							<td><?php echo e(format_date(Carbon\Carbon::createFromTimestampMs($punishment->start))); ?> <span class="badge badge-info"><?php echo e(strftime('%H:%M', $punishment->start / 1000)); ?></span></td>
							<td>
								<?php if($punishment->end != -1): ?>
									<?php echo e(format_date(Carbon\Carbon::createFromTimestampMs($punishment->end))); ?>

									<span class="badge badge-info"><?php echo e(strftime('%H:%M', $punishment->end / 1000)); ?></span>
								<?php else: ?>
									N/A
								<?php endif; ?>
							</td>
							<td class="text-right">
								<?php if(in_array($punishment, $Punishments) && $punishment->end < time()): ?>
									<?php echo e(trans('advancedban::messages.active')); ?>

								<?php else: ?>
									<?php echo e(trans('advancedban::messages.finished')); ?>

								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td colspan="7"><?php echo e(trans('advancedban::messages.no_punishments_found')); ?></td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script>
		window.addEventListener('load', function() {
			var links = document.getElementsByTagName("img");    
			var linksArr = Array.from(links);

			linksArr.forEach(function(element) {
				let profile = element;
				if(profile.getAttribute('data-name') === null) return;

				var request = new XMLHttpRequest();
				request.open('GET', 'https://api.minetools.eu/uuid/' + profile.getAttribute('data-name').replace(new RegExp("[.]", "g"), "_"), true);

				request.onreadystatechange = function() {
				  if (this.readyState === 4) {
				    if (this.status >= 200 && this.status < 400) {
				      // Success!
				      var data = JSON.parse(this.responseText);

				      if(data.id.length > 4) profile.setAttribute('src', 'https://crafatar.com/avatars/' + data.id + '?size=30');
				    }
				  }
				};

				request.send();
				request = null;
			});
		})
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/plugins/advancedban/resources/views/index.blade.php ENDPATH**/ ?>