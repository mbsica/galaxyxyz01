<?php echo csrf_field(); ?>

<div class="form-row">
    <div class="form-group col-md-4">
        <label for="nameInput"><?php echo e(trans('messages.fields.name')); ?></label>
        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nameInput" name="name" value="<?php echo e(old('name', $offer->name ?? '')); ?>" required>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-4">
        <label for="moneyInput"><?php echo e(trans('messages.fields.money')); ?></label>
        <div class="input-group">
            <input type="number" min="0" step="0.01" max="999999" class="form-control <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="moneyInput" name="money" value="<?php echo e(old('money', $offer->money ?? '')); ?>" required>
            <div class="input-group-append">
                <span class="input-group-text"><?php echo e(money_name()); ?></span>
            </div>

            <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-4">
        <label for="priceInput"><?php echo e(trans('shop::messages.fields.price')); ?></label>

        <div class="input-group mb-3">
            <input type="number" min="0" step="0.01" max="999999" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="priceInput" name="price" value="<?php echo e(old('price', $offer->price ?? '')); ?>" required>
            <div class="input-group-append">
                <span class="input-group-text"><?php echo e(currency_display()); ?></span>
            </div>

            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div>

<div class="form-group">
    <label><?php echo e(trans('shop::messages.fields.gateways')); ?></label>

    <div class="card card-body pb-0">
        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group custom-control custom-switch">
                <input type="checkbox" class="custom-control-input" id="gateways<?php echo e($gateway->id); ?>" name="gateways[<?php echo e($gateway->id); ?>]" <?php if(isset($offer) && $offer->gateways->contains($gateway)): ?> checked <?php endif; ?>>
                <label class="custom-control-label" for="gateways<?php echo e($gateway->id); ?>"><?php echo e($gateway->name); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__errorArgs = ['gateways'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback d-block" role="alert"><strong><?php echo e($message); ?></strong></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group custom-control custom-switch">
    <input type="checkbox" class="custom-control-input" id="enableSwitch" name="is_enabled" <?php if($offer->is_enabled ?? true): ?> checked <?php endif; ?>>
    <label class="custom-control-label" for="enableSwitch"><?php echo e(trans('shop::admin.offers.enable')); ?></label>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/offers/_form.blade.php ENDPATH**/ ?>