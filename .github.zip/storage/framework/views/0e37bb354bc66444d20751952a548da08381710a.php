<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="nameInput"><?php echo e(trans('messages.fields.name')); ?></label>
    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nameInput" name="name" value="<?php echo e(old('name', $category->name ?? '')); ?>" required>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group custom-control custom-switch">
    <input type="checkbox" class="custom-control-input" id="cumulatePurchasesSwitch" name="cumulate_purchases" <?php if(old('cumulate_purchases', $category->cumulate_purchases ?? false)): ?> checked <?php endif; ?>>
    <label class="custom-control-label" for="cumulatePurchasesSwitch"><?php echo e(trans('shop::admin.categories.cumulate_purchases')); ?></label>
</div>

<div class="form-group custom-control custom-switch">
    <input type="checkbox" class="custom-control-input" id="enableSwitch" name="is_enabled" <?php if(old('is_enabled', $category->is_enabled ?? true)): ?> checked <?php endif; ?>>
    <label class="custom-control-label" for="enableSwitch"><?php echo e(trans('shop::admin.categories.enable')); ?></label>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/categories/_form.blade.php ENDPATH**/ ?>