<?php $__env->startSection('title', trans('admin.servers.title-edit', ['server' => $server->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <h5><?php echo e(trans('messages.fields.status')); ?>:
                <?php if($server->isOnline()): ?>
                    <span class="badge badge-success"><?php echo e(trans_choice('admin.servers.players', $server->getOnlinePlayers())); ?></span>
                <?php else: ?>
                    <span class="badge badge-danger"><?php echo e(trans('admin.servers.offline')); ?></span>
                <?php endif; ?>
            </h5>

            <form action="<?php echo e(route('admin.servers.update', $server)); ?>" method="POST" id="serverForm">
                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('admin.servers._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>

                <a href="<?php echo e(route('admin.servers.destroy', $server)); ?>" class="btn btn-danger" data-confirm="delete">
                    <i class="fas fa-trash"></i> <?php echo e(trans('messages.actions.delete')); ?>

                </a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/servers/edit.blade.php ENDPATH**/ ?>