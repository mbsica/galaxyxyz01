<?php $__env->startSection('title', trans('errors.403.title')); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('message', $exception->getMessage() ?: trans('errors.403.message')); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/errors/403.blade.php ENDPATH**/ ?>