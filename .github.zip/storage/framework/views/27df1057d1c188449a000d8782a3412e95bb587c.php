<?php $__env->startSection('title', trans('admin.settings.mail.title')); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        const sendTestMailButton = document.getElementById('sendTestMail');

        sendTestMailButton.addEventListener('click', function () {
            const saveButtonIcon = sendTestMailButton.querySelector('.btn-spinner');

            sendTestMailButton.setAttribute('disabled', '');
            saveButtonIcon.classList.remove('d-none');

            axios.post('<?php echo e(route('admin.settings.mail.send')); ?>')
                .then(function (response) {
                    createAlert('success', response.data.message, true)
                })
                .catch(function (error) {
                    createAlert('danger', error.response.data.message ? error.response.data.message : error, true)
                })
                .finally(function () {
                    sendTestMailButton.removeAttribute('disabled');
                    saveButtonIcon.classList.add('d-none');
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <form action="<?php echo e(route('admin.settings.mail.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="mailerSelect"><?php echo e(trans('admin.settings.mail.driver')); ?></label>

                        <select class="custom-select" id="mailerSelect" name="mailer" data-toggle-select="mail-type" aria-describedby="mailerInfo">
                            <option value="" <?php if(config('mail.default') === 'array'): ?> selected <?php endif; ?>><?php echo e(trans('messages.none')); ?></option>
                            <?php $__currentLoopData = $mailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mailer => $mailerName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mailer); ?>" <?php if(config('mail.default') === $mailer): ?> selected <?php endif; ?>><?php echo e($mailerName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <small id="mailerInfo" class="form-text"><?php echo app('translator')->get('admin.settings.mail.driver-info'); ?></small>
                    </div>

                    <div class="form-group col-md-8">
                        <label for="fromAddressInput"><?php echo e(trans('admin.settings.mail.from-address')); ?></label>
                        <input type="email" class="form-control <?php $__errorArgs = ['from-address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fromAddressInput" name="from-address" value="<?php echo e(old('from-address', config('mail.from.address'))); ?>">

                        <?php $__errorArgs = ['from-address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div data-mail-type="smtp">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="smtpHostInput"><?php echo e(trans('admin.settings.mail.smtp.host')); ?></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['smtp-host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="smtpHostInput" name="smtp-host" value="<?php echo e(old('smtp-host', $smtpConfig['host'])); ?>" required>

                            <?php $__errorArgs = ['smtp-host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-3">
                            <label for="smtpPortInput"><?php echo e(trans('admin.settings.mail.smtp.port')); ?></label>
                            <input type="number" min="1" max="65535" class="form-control <?php $__errorArgs = ['smtp-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="smtpPortInput" name="smtp-port" value="<?php echo e(old('smtp-port', $smtpConfig['port'])); ?>" required>

                            <?php $__errorArgs = ['smtp-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-3">
                            <label for="smtpEncryptionSelect"><?php echo e(trans('admin.settings.mail.smtp.encryption')); ?></label>

                            <select class="custom-select" id="smtpEncryptionSelect" name="smtp-encryption">
                                <option value="" <?php if(config('mail.encryption') === null): ?> selected <?php endif; ?>><?php echo e(trans('messages.none')); ?></option>

                                <?php $__currentLoopData = $encryptionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encryption => $encryptionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($encryption); ?>" <?php if($smtpConfig['encryption'] === $encryption): ?> selected <?php endif; ?>><?php echo e($encryptionName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="smtpUsernameInput"><?php echo e(trans('admin.settings.mail.smtp.username')); ?></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['smtp-username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="smtpUsernameInput" name="smtp-username" value="<?php echo e(old('smtp-username', $smtpConfig['username'])); ?>">

                            <?php $__errorArgs = ['smtp-username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="smtpPasswordInput"><?php echo e(trans('admin.settings.mail.smtp.password')); ?></label>

                            <div class="input-group">
                                <input type="password" class="form-control <?php $__errorArgs = ['smtp-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="smtpPasswordInput" name="smtp-password" value="<?php echo e(old('smtp-password', $smtpConfig['password'])); ?>">
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-outline-primary" data-password-toggle="smtpPasswordInput">
                                        <i class="fas fa-eye-slash"></i>
                                    </button>
                                </div>

                                <?php $__errorArgs = ['smtp-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="alert alert-warning d-none" role="alert" data-mail-type="sendmail">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo e(trans('admin.settings.mail.sendmail-warn')); ?>

                </div>

                <div class="alert alert-warning d-none" role="alert" data-mail-type="undefined">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo e(trans('admin.settings.mail.disabled-warn')); ?>

                </div>

                <div class="form-group" data-mail-type="smtp sendmail">
                    <div class="form-group custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="verificationSwitch" name="users_email_verification" <?php if(setting('mail.users_email_verification')): ?> checked <?php endif; ?>>
                        <label class="custom-control-label" for="verificationSwitch"><?php echo e(trans('admin.settings.mail.enable-users-verification')); ?></label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>

                <button type="button" class="btn btn-success" id="sendTestMail" data-mail-type="smtp sendmail">
                    <i class="fas fa-paper-plane"></i>
                    <?php echo e(trans('admin.settings.mail.send')); ?>

                    <span class="spinner-border spinner-border-sm btn-spinner d-none" role="status"></span>
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/settings/mail.blade.php ENDPATH**/ ?>