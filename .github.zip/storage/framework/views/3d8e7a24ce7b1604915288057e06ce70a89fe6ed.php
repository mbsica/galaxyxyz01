

<?php $__env->startSection('title', trans('shop::admin.packages.title')); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendor/sortablejs/Sortable.min.js')); ?>"></script>
    <script>
        const sortable = Sortable.create(document.getElementById('categories'), {
            group: {
                name: 'categories',
            },
            animation: 150,
            handle: '.sortable-handle'
        });

        document.querySelectorAll('.category-list').forEach(function (el) {
            Sortable.create(el, {
                group: {
                    name: 'packages',
                },
                animation: 150,
                handle: '.sortable-handle'
            });
        });

        function serialize(categories) {
            const serialized = [];

            [].slice.call(categories.children).forEach(function (category) {
                const packagesId = [];

                const packages = category.querySelector('.category-list');

                [].slice.call(packages.children).forEach(function (categoryPackage) {
                    packagesId.push(categoryPackage.dataset['packageId']);
                });

                serialized.push({
                    id: category.dataset['categoryId'],
                    packages: packagesId
                });
            });

            return serialized
        }

        const saveButton = document.getElementById('save');
        const saveButtonIcon = saveButton.querySelector('.btn-spinner');

        saveButton.addEventListener('click', function () {
            saveButton.setAttribute('disabled', '');
            saveButtonIcon.classList.remove('d-none');

            axios.post('<?php echo e(route('shop.admin.packages.update-order')); ?>', {
                'categories': serialize(sortable.el)
            })
                .then(function (json) {
                    createAlert('success', json.data.message, true);
                })
                .catch(function (error) {
                    createAlert('danger', error, true)
                })
                .finally(function () {
                    saveButton.removeAttribute('disabled');
                    saveButtonIcon.classList.add('d-none');
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <ol class="list-unstyled sortable" id="categories">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="sortable-item sortable-dropdown mb-5" data-category-id="<?php echo e($category->id); ?>">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between">
                                <span>
                                    <i class="fas fa-arrows-alt sortable-handle"></i>
                                    <a href="<?php echo e(route('shop.categories.show', $category)); ?>"><?php echo e($category->name); ?></a>
                                </span>
                                <span>
                                    <a href="<?php echo e(route('shop.admin.categories.edit', $category)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                    <a href="<?php echo e(route('shop.admin.categories.destroy', $category)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                                </span>
                            </div>
                        </div>
                        <ol class="list-unstyled sortable sortable-list category-list">
                            <?php $__currentLoopData = $category->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sortable-item" data-package-id="<?php echo e($package->id); ?>">
                                    <div class="card">
                                        <div class="card-body d-flex justify-content-between">
                                            <span>
                                                <i class="fas fa-arrows-alt sortable-handle"></i>
                                                <?php echo e($package->name); ?>

                                            </span>
                                            <span>
                                                <a href="<?php echo e(route('shop.admin.packages.edit', $package)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(route('shop.admin.packages.destroy', $package)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>

            <a href="<?php echo e(route('shop.admin.categories.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> <?php echo e(trans('shop::admin.packages.create-category')); ?>

            </a>

            <?php if(! $categories->isEmpty()): ?>
                <a href="<?php echo e(route('shop.admin.packages.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> <?php echo e(trans('shop::admin.packages.create-package')); ?>

                </a>

                <button type="button" class="btn btn-success" id="save">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                    <span class="spinner-border spinner-border-sm btn-spinner d-none" role="status"></span>
                </button>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/plugins/shop/resources/views/admin/packages/index.blade.php ENDPATH**/ ?>