

<?php $__env->startSection('title', trans('shop::admin.offers.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.price')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.money')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($offer->id); ?></th>
                            <td><?php echo e($offer->name); ?></td>
                            <td><?php echo e($offer->price); ?> <?php echo e(currency_display()); ?></td>
                            <td><?php echo e(format_money($offer->money)); ?></td>
                            <td>
                                <a href="<?php echo e(route('shop.admin.offers.edit', $offer)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('shop.admin.offers.destroy', $offer)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <a class="btn btn-primary" href="<?php echo e(route('shop.admin.offers.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/offers/index.blade.php ENDPATH**/ ?>