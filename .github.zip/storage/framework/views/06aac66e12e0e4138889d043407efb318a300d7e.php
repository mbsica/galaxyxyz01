<?php echo $__env->make('admin.elements.color-picker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo csrf_field(); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        document.querySelectorAll('[data-role-permission]').forEach(function (el) {
            const perm = el.dataset['rolePermission'];

            if (!perm.includes('admin.') || perm === 'admin.access') {
                return;
            }

            el.addEventListener('change', function () {
                if (el.checked) {
                    document.querySelector('[name="permissions[admin.access]"]').checked = true;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<div class="form-row">
    <div class="form-group col-md-6">
        <label for="nameInput"><?php echo e(trans('messages.fields.name')); ?></label>
        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nameInput" name="name" value="<?php echo e(old('name', $role->name ?? '')); ?>" required>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6 mb-4">
        <label for="colorInput"><?php echo e(trans('messages.fields.color')); ?></label>
        <input type="color" class="form-control form-control-color color-picker <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="colorInput" name="color" value="<?php echo e(old('color', $role->color ?? '#2196f3')); ?>" required>

        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<h3><?php echo e(trans('admin.roles.permissions')); ?></h3>

<div class="form-group mb-2">
    <div class="custom-control custom-switch">
        <input type="checkbox" class="custom-control-input" id="adminSwitch" name="is_admin" data-toggle="collapse" data-target="#permissionsGroup" <?php if($role->is_admin ?? false): ?> checked <?php endif; ?> aria-describedby="adminInfo">
        <label class="custom-control-label" for="adminSwitch"><?php echo e(trans('admin.roles.perm-admin.label')); ?></label>
    </div>

    <small id="adminInfo" class="form-text text-info"><?php echo e(trans('admin.roles.perm-admin.info')); ?></small>
</div>

<div id="permissionsGroup" class="<?php echo e(($role->is_admin ?? false) ? 'collapse' : 'show'); ?>">
    <div class="card card-body mb-2">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission => $permissionDescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group custom-control custom-switch">
                <input type="checkbox" class="custom-control-input" id="permission<?php echo e($loop->index); ?>" name="permissions[<?php echo e($permission); ?>]" <?php if(isset($role) && $role->hasRawPermission($permission) ?? false): ?> checked <?php endif; ?> data-role-permission="<?php echo e($permission); ?>">
                <label class="custom-control-label" for="permission<?php echo e($loop->index); ?>"><?php echo e(trans($permissionDescription)); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/roles/_form.blade.php ENDPATH**/ ?>