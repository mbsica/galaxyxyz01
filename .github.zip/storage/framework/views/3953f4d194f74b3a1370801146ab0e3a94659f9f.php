

<?php $__env->startSection('title', trans('shop::messages.payment.title')); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        document.querySelectorAll('.payment-method').forEach(function (el) {
            el.addEventListener('click', function (ev) {
                ev.preventDefault();

                const form = document.getElementById('submitForm');
                form.action = el.href;
                form.submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container content">
        <h1><?php echo e(trans('shop::messages.payment.title')); ?></h1>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3">
                    <div class="card shadow-sm mb-3">
                        <a href="<?php echo e(route('shop.payments.pay', $gateway->type)); ?>" class="payment-method">
                            <div class="card-body text-center">
                                <img src="<?php echo e($gateway->paymentMethod()->image()); ?>" style="max-height: 45px" class="img-fluid" alt="<?php echo e($gateway->name); ?>">
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col">
                    <div class="alert alert-warning" role="alert">
                        <?php echo e(trans('shop::messages.payment.empty')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <form method="POST" id="submitForm">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/payments/pay.blade.php ENDPATH**/ ?>