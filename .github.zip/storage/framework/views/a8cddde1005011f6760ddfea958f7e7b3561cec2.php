<?php $__env->startSection('title', trans('errors.500.title')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', trans('errors.500.message')); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/errors/500.blade.php ENDPATH**/ ?>