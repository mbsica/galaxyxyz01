<div class="accordion" id="accordionExample">
    <div class="card" style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
        <div class="card-header package-games">
            <img src="<?php echo e(URL::asset('public/assets/img/home1.png')); ?>" alt="">
            <a href="/galaxy/shop" class="btn-block">
              Home
            </a>
        </div>
    </div>
    <div class="card"  style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
        <div class="card-header package-games" id="headFactions">
          <img src="<?php echo e(URL::asset('public/assets/img/factions.png')); ?>" alt="">
          <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseFactions" aria-expanded="false" aria-controls="collapseFactions">
              Factions<i class="fas fa-sort-down blablabla11"></i>
          </a>
        </div>
        <div id="collapseFactions" class="collapse" aria-labelledby="headFactions" data-parent="#accordionExample">
            <ul class="list-group">
              <a href="/galaxy/shop/categories/1"><li class="list-group-item">Factions Ranks</li></a>
              <a href="/galaxy/shop/categories/3"><li class="list-group-item">Factions Rank Upgrade</li></a>
              <a href="/galaxy/shop/categories/2"><li class="list-group-item">Factions GKIT</li></a>
              <a href="/galaxy/shop/categories/4"><li class="list-group-item">Factions Crate Keys</li></a>
              <a href="/galaxy/shop/categories/5"><li class="list-group-item">Factions Commands</li></a>
              <a href="/galaxy/shop/categories/6"><li class="list-group-item">Бусад хэрэгцээт</li></a>
            </ul>
        </div>
      </div>
      <div class="card"  style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
        <div class="card-header package-games" id="headSky">
          <img src="<?php echo e(URL::asset('public/assets/img/skyblock1.png')); ?>" alt="">
          <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseSky" aria-expanded="false" aria-controls="collapseSky">
              Skyblock <i class="fas fa-sort-down blablabla11"></i>
          </a>
          </div>
          <div id="collapseSky" class="collapse" aria-labelledby="headSky" data-parent="#accordionExample">
              <ul class="list-group">
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
              </ul>
          </div>
      </div>
      <div class="card" style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
        <div class="card-header package-games" id="headingOne">
          <img src="<?php echo e(URL::asset('public/assets/img/spawner3.png')); ?>" alt="">
          <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
              Prison <i class="fas fa-sort-down blablabla11"></i>
            </a>
          </div>
          <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
              <ul class="list-group">
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                  <li class="list-group-item"><a href="#">Factions Ranks</a></li>
              </ul>
          </div>
      </div>
    <div class="card" style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
      <div class="card-header package-games" id="headingTwo">
        <img src="<?php echo e(URL::asset('public/assets/img/grass-block.png')); ?>" alt="">
        <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Survival<i class="fas fa-sort-down blablabla11"></i>
        </a>
        </div>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
            <ul class="list-group">
                <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                <li class="list-group-item"><a href="#">Factions Ranks</a></li>
                <li class="list-group-item"><a href="#">Factions Ranks</a></li>
            </ul>
        </div>
    </div>
    <div class="card" style="border-bottom: 1px solid rgba(118, 118, 118, 0.405)">
      <div class="card-header package-games" id="headingThree">
          <img src="<?php echo e(URL::asset('public/assets/img/omegatrainer.png')); ?>" alt="">
          <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            MiniGames <i class="fas fa-sort-down blablabla11"></i>
          </a>
      </div>
        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
            <ul class="list-group">
                <li class="list-group-item">Cras justo odio</li>
                <li class="list-group-item">Dapibus ac facilisis in</li>
                <li class="list-group-item">Morbi leo risus</li>
                <li class="list-group-item">Porta ac consectetur ac</li>
                <li class="list-group-item">Vestibulum at eros</li>
            </ul>
        </div>
    </div>
    <div class="card">
      <div class="card-header package-games" id="headingFour">
          <img src="<?php echo e(URL::asset('public/assets/img/coin11.png')); ?>" alt="">
          <a class="btn-block collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
            Other <i class="fas fa-sort-down blablabla11"></i>
          </a>
      </div>
        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
            <ul class="list-group">
                <li class="list-group-item">Cras justo odio</li>
                <li class="list-group-item">Dapibus ac facilisis in</li>
                <li class="list-group-item">Morbi leo risus</li>
                <li class="list-group-item">Porta ac consectetur ac</li>
                <li class="list-group-item">Vestibulum at eros</li>
            </ul>
        </div>
    </div>
</div>
  
<?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/categories/sidebar.blade.php ENDPATH**/ ?>