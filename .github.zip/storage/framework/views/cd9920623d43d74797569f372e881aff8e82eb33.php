<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->yieldPushContent('meta'); ?>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'Admin'); ?> | <?php echo e(site_name()); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/azuriom.png')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/axios/axios.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/sb-admin-2/js/sb-admin-2.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('admin/js/admin.js')); ?>?v000208" defer></script>

    <!-- Page level scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,700,800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('vendor/sb-admin-2/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/admin.css')); ?>" rel="stylesheet">
    <?php if(dark_theme()): ?>
        <link href="<?php echo e(asset('admin/css/dark.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<div id="app">
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <nav class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
                <div class="sidebar-brand-icon">
                    <img src="<?php echo e(asset('svg/azuriom-white.svg')); ?>" alt="Azuriom">
                </div>
                <div class="sidebar-brand-text mx-3">
                    <img src="<?php echo e(asset('svg/azuriom-text-white.svg')); ?>" alt="Azuriom">
                    <sup><?php echo e(Azuriom::version()); ?></sup>

                    <small class="font-weight-bold"><?php echo e(game()->name()); ?></small>
                </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <div class="nav-item <?php echo e(add_active('admin.dashboard')); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span><?php echo e(trans('admin.nav.dashboard')); ?></span></a>
            </div>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.settings', 'admin.navbar', 'admin.servers'])): ?>
                <hr class="sidebar-divider">

                <div class="sidebar-heading"><?php echo e(trans('admin.nav.settings.heading')); ?></div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.settings')): ?>
                <div class="nav-item <?php echo e(add_active('admin.settings.*')); ?>">
                    <a class="nav-link <?php echo e(Route::is('admin.settings.*') ? '' : 'collapsed'); ?>" href="#" data-toggle="collapse" data-target="#collapseSettings" aria-expanded="true" aria-controls="collapseSettings">
                        <i class="fas fa-fw fa-cogs"></i>
                        <span><?php echo e(trans('admin.nav.settings.heading')); ?></span>
                    </a>
                    <div id="collapseSettings" class="collapse <?php echo e(Route::is('admin.settings.*') ? 'show' : ''); ?>" data-parent="#accordionSidebar">
                        <div class="bg-white py-2 collapse-inner rounded">
                            <h6 class="collapse-header"><?php echo e(trans('admin.nav.settings.settings.settings')); ?></h6>
                            <a class="collapse-item <?php echo e(add_active('admin.settings.index')); ?>" href="<?php echo e(route('admin.settings.index')); ?>"><?php echo e(trans('admin.nav.settings.settings.global')); ?></a>
                            <a class="collapse-item <?php echo e(add_active('admin.settings.seo')); ?>" href="<?php echo e(route('admin.settings.seo')); ?>"><?php echo e(trans('admin.nav.settings.settings.seo')); ?></a>
                            <?php if(! oauth_login()): ?>
                                <a class="collapse-item <?php echo e(add_active('admin.settings.auth')); ?>" href="<?php echo e(route('admin.settings.auth')); ?>"><?php echo e(trans('admin.nav.settings.settings.auth')); ?></a>
                                <a class="collapse-item <?php echo e(add_active('admin.settings.mail')); ?>" href="<?php echo e(route('admin.settings.mail')); ?>"><?php echo e(trans('admin.nav.settings.settings.mail')); ?></a>
                            <?php endif; ?>
                            <a class="collapse-item <?php echo e(add_active('admin.settings.performance')); ?>" href="<?php echo e(route('admin.settings.performance')); ?>"><?php echo e(trans('admin.nav.settings.settings.performances')); ?></a>
                            <a class="collapse-item <?php echo e(add_active('admin.settings.maintenance')); ?>" href="<?php echo e(route('admin.settings.maintenance')); ?>"><?php echo e(trans('admin.nav.settings.settings.maintenance')); ?></a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.navbar')): ?>
                <div class="nav-item <?php echo e(add_active('admin.navbar-elements.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.navbar-elements.index')); ?>">
                        <i class="fas fa-fw fa-bars"></i>
                        <span><?php echo e(trans('admin.nav.settings.navbar')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.servers')): ?>
                <div class="nav-item <?php echo e(add_active('admin.servers.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.servers.index')); ?>">
                        <i class="fas fa-fw fa-server"></i>
                        <span><?php echo e(trans('admin.nav.settings.servers')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.users', 'admin.roles'])): ?>
                <hr class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading"><?php echo e(trans('admin.nav.users.heading')); ?></div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.users')): ?>
                <div class="nav-item <?php echo e(add_active('admin.users.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>">
                        <i class="fas fa-fw fa-users"></i>
                        <span><?php echo e(trans('admin.nav.users.users')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.roles')): ?>
                <div class="nav-item <?php echo e(add_active('admin.roles.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.roles.index')); ?>">
                        <i class="fas fa-fw fa-user-tag"></i>
                        <span><?php echo e(trans('admin.nav.users.roles')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.users')): ?>
                <div class="nav-item <?php echo e(add_active('admin.bans.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.bans.index')); ?>">
                        <i class="fas fa-fw fa-user-times"></i>
                        <span><?php echo e(trans('admin.nav.users.bans')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.pages', 'admin.posts', 'admin.images'])): ?>
                <hr class="sidebar-divider">

                <div class="sidebar-heading"><?php echo e(trans('admin.nav.content.heading')); ?></div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.pages')): ?>
                <div class="nav-item <?php echo e(add_active('admin.pages.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.pages.index')); ?>">
                        <i class="fas fa-fw fa-file-alt"></i>
                        <span><?php echo e(trans('admin.nav.content.pages')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.posts')): ?>
                <div class="nav-item <?php echo e(add_active('admin.posts.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.posts.index')); ?>">
                        <i class="fas fa-fw fa-newspaper"></i>
                        <span><?php echo e(trans('admin.nav.content.posts')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.images')): ?>
                <div class="nav-item <?php echo e(add_active('admin.images.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.images.index')); ?>">
                        <i class="fas fa-fw fa-image"></i>
                        <span><?php echo e(trans('admin.nav.content.images')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.plugins', 'admin.themes'])): ?>
                <hr class="sidebar-divider">

                <div class="sidebar-heading"><?php echo e(trans('admin.nav.extensions.heading')); ?></div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.plugins')): ?>
                <div class="nav-item <?php echo e(add_active('admin.plugins.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.plugins.index')); ?>">
                        <i class="fas fa-fw fa-puzzle-piece"></i>
                        <span><?php echo e(trans('admin.nav.extensions.plugins')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.themes')): ?>
                <div class="nav-item <?php echo e(add_active('admin.themes.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.themes.index')); ?>">
                        <i class="fas fa-fw fa-paint-brush"></i>
                        <span><?php echo e(trans('admin.nav.extensions.themes')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if(! plugins()->getAdminNavItems()->isEmpty()): ?>
                <hr class="sidebar-divider">

                <div class="sidebar-heading">Plugins</div>
            <?php endif; ?>

            <?php $__currentLoopData = plugins()->getAdminNavItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navId => $navItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(! isset($navItem['permission']) || Gate::check($navItem['permission'])): ?>
                    <?php if($navItem['type'] ?? '' === 'dropdown'): ?>
                        <div class="nav-item <?php if(isset($navItem['route'])): ?> <?php echo e(add_active($navItem['route'])); ?> <?php endif; ?>">
                            <a class="nav-link <?php if(! isset($navItem['route']) || ! Route::is($navItem['route'])): ?> collapsed <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapse<?php echo e(ucfirst($navId)); ?>" aria-expanded="true" aria-controls="collapse<?php echo e(ucfirst($navId)); ?>">
                                <i class="fa-fw <?php echo e($navItem['icon']); ?>"></i>
                                <span><?php echo e(trans($navItem['name'])); ?></span>
                            </a>
                            <div id="collapse<?php echo e(ucfirst($navId)); ?>" class="collapse <?php if(isset($navItem['route']) && Route::is($navItem['route'])): ?> show <?php endif; ?>" data-parent="#accordionSidebar">
                                <div class="bg-white py-2 collapse-inner rounded">
                                    <?php $__currentLoopData = $navItem['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="collapse-item <?php echo e(add_active(str_replace('index', '*', $route))); ?>" href="<?php echo e(route($route)); ?>"><?php echo e(trans($name)); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="nav-item <?php echo e(add_active($navItem['route'])); ?>">
                            <a class="nav-link" href="<?php echo e(route($navItem['route'])); ?>">
                                <i class="fa-fw <?php echo e($navItem['icon']); ?>"></i>
                                <span><?php echo e(trans($navItem['name'])); ?></span>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin.update', 'admin.logs'])): ?>
                <hr class="sidebar-divider">

                <div class="sidebar-heading"><?php echo e(trans('admin.nav.other.heading')); ?></div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.update')): ?>
                <div class="nav-item <?php echo e(add_active('admin.update.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.update.index')); ?>">
                        <i class="fas fa-fw fa-cloud-download-alt"></i>
                        <span><?php echo e(trans('admin.nav.other.update')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.logs')): ?>
                <div class="nav-item <?php echo e(add_active('admin.logs.*')); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.logs.index')); ?>">
                        <i class="fas fa-fw fa-history"></i>
                        <span><?php echo e(trans('admin.nav.other.logs')); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <hr class="sidebar-divider">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </nav>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <div class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100">
                        <a href="https://azuriom.com/discord" class="btn btn-outline-primary mx-1" target="_blank" rel="noopener noreferrer">
                            <i class="fas fa-question-circle"></i>
                            <?php echo e(trans('admin.nav.support')); ?>

                        </a>

                        <a href="https://azuriom.com/docs" class="btn btn-outline-secondary mx-1" target="_blank" rel="noopener noreferrer">
                            <i class="fas fa-book"></i>
                            <?php echo e(trans('admin.nav.documentation')); ?>

                        </a>
                    </div>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <?php if($hasUpdate): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.update')): ?>
                                <li class="nav-item mx-1">
                                    <a class="nav-link text-info" href="<?php echo e(route('admin.update.index')); ?>">
                                        <i class="fas fa-cloud-download-alt"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>

                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <!-- Counter - Notifications -->
                                <i class="fas fa-bell fa-fw"></i>
                                <?php if(! $notifications->isEmpty()): ?>
                                    <span class="badge badge-danger badge-counter" id="notificationsCounter"><?php echo e($notifications->count()); ?></span>
                                <?php endif; ?>
                            </a>

                            <!-- Dropdown - Notifications -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="notificationsDropdown">
                                <h6 class="dropdown-header"><?php echo e(trans('messages.notifications.notifications')); ?></h6>

                                <?php if(! $notifications->isEmpty()): ?>
                                    <div id="notifications">
                                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e($notification->link ? url($notification->link) : '#'); ?>" class="dropdown-item d-flex align-items-center">
                                                <div class="mr-3">
                                                    <div class="icon-circle text-white bg-<?php echo e($notification->level); ?>">
                                                        <i class="fas fa-<?php echo e($notification->icon()); ?> fa-fw"></i>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="small text-gray-500"><?php echo e(format_date($notification->created_at, true)); ?></div>
                                                    <?php echo e($notification->content); ?>

                                                </div>
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <a href="<?php echo e(route('notifications.read.all')); ?>" id="readNotifications" class="dropdown-item text-center small text-gray-500">
                                            <span class="d-none spinner-border spinner-border-sm loader" role="status"></span>
                                            <?php echo e(trans('messages.notifications.read')); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>

                                <div id="noNotificationsLabel" class="dropdown-item text-center small text-success <?php if(! $notifications->isEmpty()): ?> d-none <?php endif; ?>">
                                    <i class="fas fa-check"></i> <?php echo e(trans('messages.notifications.empty')); ?>

                                </div>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                                <img class="img-profile rounded-circle" src="<?php echo e(auth()->user()->getAvatar()); ?>" alt="Avatar">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('admin.users.edit', Auth::user())); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(trans('admin.nav.profile.profile')); ?>

                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('profile.theme')); ?>" data-route="theme">
                                    <i class="fas fa-<?php echo e(dark_theme() ? 'sun' : 'moon'); ?> fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(trans('messages.theme.'.(dark_theme() ? 'light' : 'dark'))); ?>

                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('home')); ?>">
                                    <i class="fas fa-home fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(trans('admin.nav.back-website')); ?>

                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" data-route="logout">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(trans('auth.logout')); ?>

                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800"><?php echo $__env->yieldContent('title', 'Admin'); ?></h1>
                    </div>

                    <?php echo $__env->make('admin.elements.session-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>
                            <?php echo app('translator')->get('admin.footer', [
                                'year' => '2019-'.now()->year,
                                'azuriom' => '<a href="https://azuriom.com" target="_blank" rel="noopener noreferrer">Azuriom</a>',
                                'startbootstrap' => '<a href="https://startbootstrap.com" target="_blank" rel="noopener noreferrer">Start Bootstrap</a>'
                            ]); ?>
                        </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#app">
        <i class="fas fa-angle-up"></i>
    </a>
</div>

<!-- Delete confirm modal -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="confirmDeleteLabel"><?php echo e(trans('admin.confirm-delete.title')); ?></h2>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body"><?php echo e(trans('admin.confirm-delete.description')); ?></div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">
                    <i class="fas fa-arrow-left"></i> <?php echo e(trans('messages.actions.cancel')); ?></button>
                <form id="confirmDeleteForm" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>

                    <button class="btn btn-danger" type="submit">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo e(trans('messages.actions.delete')); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>

<form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>

<form id="themeForm" action="<?php echo e(route('profile.theme')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="theme" value="<?php echo e(dark_theme() ? 'light' : 'dark'); ?>">
</form>

<?php echo $__env->yieldPushContent('footer-scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/layouts/admin.blade.php ENDPATH**/ ?>