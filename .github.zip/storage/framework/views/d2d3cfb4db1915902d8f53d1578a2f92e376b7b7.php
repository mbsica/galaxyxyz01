

<?php $__env->startSection('title', trans('shop::messages.cart.title')); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .cart-items thead th {
            width: 40%;
        }

        .cart-items tbody td {
            width: 15%;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div style="height: 30px"></div>
    <div class="container pl-0 pr-0">
        <div class="h3 deco-h"><span> <span class="text-red"><?php echo e(trans('shop::messages.cart.title')); ?></span></span></div>
    </div>
    <div class="container shop-card">
        <?php if(! $cart->isEmpty()): ?>

            <form action="<?php echo e(route('shop.cart.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <table class="table cart-items">
                    <thead>
                    <tr>
                        <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.price')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.total')); ?></th>
                        <th scope="col"><?php echo e(trans('shop::messages.fields.quantity')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $cart->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($cartItem->name()); ?></th>
                            <td><?php echo e(shop_format_amount($cartItem->price())); ?></td>
                            <td><?php echo e(shop_format_amount($cartItem->total())); ?></td>
                            <td>
                                <input type="number" min="0" max="<?php echo e($cartItem->maxQuantity()); ?>" size="5" class="form-control form-control-sm d-inline-block" name="quantities[<?php echo e($cartItem->itemId); ?>]" value="<?php echo e($cartItem->quantity); ?>" aria-label="<?php echo e(trans('shop::messages.fields.quantity')); ?>" required <?php if(!$cartItem->hasQuantity()): ?> readonly <?php endif; ?>>
                            </td>
                            <td>
                                <a href="<?php echo e(route('shop.cart.remove', $cartItem->id)); ?>" class="btn btn-sm btn-danger" title="<?php echo e(trans('messages.actions.delete')); ?>">
                                    <i class="fas fa-times fa-fw"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

                <p class="text-right mb-4">
                    <button type="submit" class="btn btn-info btn-sm">
                        <?php echo e(trans('messages.actions.update')); ?>

                    </button>
                </p>
            </form>

            <div class="row">
                <div class="col-md-8">
                    <h5 style="color: #c51b1b;"><?php echo e(trans('shop::messages.cart.coupons')); ?></h5>

                    <table class="table coupons">
                        <thead>
                        <tr>
                            <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                            <th scope="col"><?php echo e(trans('shop::messages.fields.discount')); ?></th>
                            <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $cart->coupons(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($coupon->code); ?></th>
                                <td><?php echo e($coupon->discount); ?>%</td>
                                <td>
                                    <form action="<?php echo e(route('shop.cart.coupons.remove', $coupon)); ?>" method="POST" class="d-inline-block">
                                        <?php echo csrf_field(); ?>

                                        <button type="submit" class="btn btn-sm btn-danger" title="<?php echo e(trans('messages.actions.delete')); ?>">
                                            <i class="fas fa-times fa-fw"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

                <div class="col-md-4">
                    <h5 style="color: #c51b1b;"><?php echo e(trans('shop::messages.cart.add-coupon')); ?></h5>

                    <form action="<?php echo e(route('shop.cart.coupons.add')); ?>" method="POST" class="form-inline mb-3">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mx-2" placeholder="Code" id="code" name="code" value="<?php echo e(old('code')); ?>">

                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-info"><?php echo e(trans('messages.actions.add')); ?></button>
                    </form>
                </div>
            </div>

            <p class="font-weight-bold text-right mb-4">
                <span class="border border-dark p-2 rounded">
                    <?php echo e(trans('shop::messages.cart.total', ['total' => shop_format_amount($cart->total())])); ?>

                </span>
            </p>

            <div class="row">
                <div class="col-md-6">
                    <a href="<?php echo e(route('shop.home')); ?>" class="btn btn-secondary">
                        <?php echo e(trans('shop::messages.cart.back')); ?>

                    </a>
                </div>

                <div class="col-md-6 text-right">
                    <form method="POST" action="<?php echo e(route('shop.cart.clear')); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>

                        <button type="submit" class="btn btn-danger">
                            <?php echo e(trans('shop::messages.cart.clear')); ?>

                        </button>
                    </form>

                    <?php if(use_site_money()): ?>
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#confirmBuyModal">
                            <?php echo e(trans('shop::messages.buy')); ?>

                        </button>
                    <?php else: ?>
                        <a href="<?php echo e(route('shop.payments.payment')); ?>" class="btn btn-success">
                            <?php echo e(trans('shop::messages.cart.checkout')); ?>

                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-warning" role="alert">
                <?php echo e(trans('shop::messages.cart.empty')); ?>

            </div>

            <a href="<?php echo e(route('shop.home')); ?>" class="btn btn-secondary">
                <?php echo e(trans('shop::messages.cart.back')); ?>

            </a>
        <?php endif; ?>
    </div>

    <?php if(use_site_money()): ?>
        <div class="modal fade" id="confirmBuyModal" tabindex="-1" role="dialog" aria-labelledby="confirmBuyLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="confirmBuyLabel"><?php echo e(trans('shop::messages.cart.pay-confirm-title')); ?></h2>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true"><i class="fas fa-window-close"></i></span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo e(trans('shop::messages.cart.pay-confirm', ['price' => shop_format_amount($cart->total())])); ?>

                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal"><?php echo e(trans('messages.actions.cancel')); ?></button>

                        <form method="POST" action="<?php echo e(route('shop.cart.payment')); ?>">
                            <?php echo csrf_field(); ?>

                            <button class="btn btn-success" type="submit">
                                <?php echo e(trans('shop::messages.cart.pay')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/cart/index.blade.php ENDPATH**/ ?>