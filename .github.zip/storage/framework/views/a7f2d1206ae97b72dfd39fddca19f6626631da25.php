<div class="nk-widget">
    <div class="nk-widget-content">
        <form action="#" novalidate="novalidate">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Type something...">
                <button class="btn btn-danger"><i class="fas fa-search"></i></button>
            </div>
        </form>
    </div>
</div>
<div class="widget">
    <h4 class="nk-widget-title pr-0"><div class="h4 deco-h-2 pr-0"><span> <span class="text-red">We are</span> social</span></div></h4>
    <div class="widget-content">
        <ul class="nk-social-links-3">
            <li><a href="#" class="social-icon-twitch"><i class="fab fa-twitch"></i></a></li>
            <li><a href="#" class="social-icon-insta"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#" class="social-icon-fb"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#" class="social-icon-google"><i class="fab fa-google-plus"></i></a></li>
            <li><a href="#" class="social-icon-yt"><i class="fab fa-youtube"></i></a></li>
            <li><a href="#" class="social-icon-twitter"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#" class="social-icon-pinta"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#" class="social-icon-rss"><i class="fas fa-rss"></i></a></li>
        </ul>
    </div>
</div>
<div class="widget">
    <h4 class="nk-widget-title pr-0"><div class="h4 deco-h-2 pr-0"><span> <span class="text-red">Online</span> staff</span></div></h4>
    <div class="widget-content">

        <div>sss</div>
    </div>
</div><?php /**PATH /home/galaowmw/galaxy/resources/views/elements/widgets.blade.php ENDPATH**/ ?>