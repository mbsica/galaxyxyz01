

<?php $__env->startSection('title', trans('advancedban::admin.settings.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <form action="<?php echo e(route('advancedban.admin.settings')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="host"><?php echo e(trans('advancedban::admin.settings.host')); ?></label>
                    <input class="form-control" id="host" name="host" value="<?php echo e($host); ?>" required="required">
                </div>

                <div class="form-group">
                    <label for="port"><?php echo e(trans('advancedban::admin.settings.port')); ?></label>
                    <input class="form-control" id="port" name="port" value="<?php echo e($port); ?>" required="required">
                </div>

                <div class="form-group">
                    <label for="database"><?php echo e(trans('advancedban::admin.settings.database')); ?></label>
                    <input class="form-control" id="database" name="database" value="<?php echo e($database); ?>" required="required">
                </div>

                <div class="form-group">
                    <label for="username"><?php echo e(trans('advancedban::admin.settings.username')); ?></label>
                    <input class="form-control" id="username" name="username" value="<?php echo e($username); ?>" required="required">
                </div>
                
                <div class="form-group">
                    <label for="password"><?php echo e(trans('advancedban::admin.settings.password')); ?></label>
                    <input class="form-control" id="password" name="password" value="<?php echo e($password); ?>" required="required">
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>

            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/advancedban/resources/views/admin/settings.blade.php ENDPATH**/ ?>