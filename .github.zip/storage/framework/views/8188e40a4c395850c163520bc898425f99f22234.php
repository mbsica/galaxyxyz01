<?php $__env->startSection('title', trans('admin.settings.auth.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.settings.auth.title')); ?></h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.settings.auth.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="conditionsInput"><?php echo e(trans('admin.settings.auth.conditions-url')); ?></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['conditions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="conditionsInput" name="conditions" value="<?php echo e(old('conditions', $conditions)); ?>" aria-describedby="conditionsLabel">

                    <?php $__errorArgs = ['conditions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <small id="conditionsLabel" class="form-text"><?php echo e(trans('admin.settings.auth.conditions-info')); ?></small>
                </div>

                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="registerInput" name="register" <?php if($register): ?> checked <?php endif; ?> aria-describedby="registerInput">
                        <label class="custom-control-label" for="registerInput"><?php echo e(trans('admin.settings.auth.enable-user-registration')); ?></label>
                    </div>

                    <small id="registerInput" class="form-text"><?php echo e(trans('admin.settings.auth.enable-user-registration-label')); ?></small>
                </div>

                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="authApiInput" name="auth-api" <?php if($authApi): ?> checked <?php endif; ?> aria-describedby="authApiInfo">
                        <label class="custom-control-label" for="authApiInput"><?php echo e(trans('admin.settings.auth.auth-api')); ?></label>
                    </div>

                    <small id="authApiInfo" class="form-text"><?php echo app('translator')->get('admin.settings.auth.auth-api-label'); ?></small>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.settings.security.title')); ?></h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.settings.security.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="captchaSelect"><?php echo e(trans('admin.settings.security.captcha.title')); ?></label>
                    <select class="custom-select <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="captchaSelect" name="captcha" data-toggle-select="captcha-type">
                        <option value=""><?php echo e(trans('messages.none')); ?></option>
                        <option value="hcaptcha" <?php if($captchaType === 'hcaptcha'): ?> selected <?php endif; ?>>hCaptcha</option>
                        <option value="recaptcha" <?php if($captchaType === 'recaptcha'): ?> selected <?php endif; ?>>reCaptcha</option>
                    </select>

                    <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div data-captcha-type="recaptcha hcaptcha">
                    <div class="card card-body mb-2">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="siteKeyInput"><?php echo e(trans('admin.settings.security.captcha.site-key')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['site_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="siteKeyInput" name="site_key" value="<?php echo e(old('captcha.site_key', setting('captcha.site_key', ''))); ?>">

                                <?php $__errorArgs = ['site_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <small class="form-text" data-captcha-type="recaptcha">
                                    <?php echo app('translator')->get('admin.settings.security.captcha.recaptcha'); ?>
                                </small>

                                <small class="form-text" data-captcha-type="hcaptcha">
                                    <?php echo app('translator')->get('admin.settings.security.captcha.hcaptcha'); ?>
                                </small>
                            </div>

                            <div class="form-group col-md-6 mb-0">
                                <label for="secretKeyInput"><?php echo e(trans('admin.settings.security.captcha.secret-key')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="secretKeyInput" name="secret_key" value="<?php echo e(old('secret_key', setting('captcha.secret_key', ''))); ?>">

                                <?php $__errorArgs = ['secret_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="hashSelect"><?php echo e(trans('admin.settings.security.hash')); ?></label>
                    <select class="custom-select <?php $__errorArgs = ['hash'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hashSelect" name="hash" required aria-describedby="hashInfo">
                        <?php $__currentLoopData = $hashAlgorithms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hash => $hashName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hash); ?>" <?php if($currentHash === $hash): ?> selected <?php endif; ?>><?php echo e($hashName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['hash'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <small id="hashInfo" class="form-text"><?php echo e(trans('admin.settings.security.hash-info')); ?></small>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/settings/authentification.blade.php ENDPATH**/ ?>