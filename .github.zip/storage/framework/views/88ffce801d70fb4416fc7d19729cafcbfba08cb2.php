<?php $__env->startSection('title', trans('admin.roles.title')); ?>

<?php if(Auth::user()->isAdmin()): ?>
    <?php $__env->startPush('footer-scripts'); ?>
        <script src="<?php echo e(asset('vendor/sortablejs/Sortable.min.js')); ?>"></script>
        <script>
            const sortable = Sortable.create(document.getElementById('roles'), {
                animation: 150,
                group: 'role',
                handle: '.sortable-handle',
            });

            function serialize(sortable) {
                const serialized = [];

                [].slice.call(sortable.children).forEach(function (child) {
                    serialized.push(child.dataset['id']);
                });

                return serialized
            }

            const saveButton = document.getElementById('save');
            const saveButtonIcon = saveButton.querySelector('.btn-spinner');

            saveButton.addEventListener('click', function () {
                saveButton.setAttribute('disabled', '');
                saveButtonIcon.classList.remove('d-none');

                axios.post('<?php echo e(route('admin.roles.update-power')); ?>', {
                    'roles': serialize(sortable.el).reverse()
                }).then(function (json) {
                    createAlert('success', json.data.message, true);
                }).catch(function (error) {
                    createAlert('danger', error.response.data.message ? error.response.data.message : error, true)
                }).finally(function () {
                    saveButton.removeAttribute('disabled');
                    saveButtonIcon.classList.add('d-none');
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <ol class="list-unstyled sortable mb-3" id="roles">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="sortable-item sortable-dropdown" data-id="<?php echo e($role->id); ?>">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between">
                                <span>
                                    <?php if(Auth::user()->isAdmin()): ?>
                                        <i class="fas fa-arrows-alt sortable-handle"></i>
                                    <?php endif; ?>

                                    <span class="badge badge-label" style="<?php echo e($role->getBadgeStyle()); ?>; font-size: 1.05em"><?php echo e($role->name); ?></span>

                                    <?php if($role->isDefault()): ?>
                                        <i class="fas fa-star text-info" title="<?php echo e(trans('admin.roles.info.default')); ?>" data-toggle="tooltip"></i>
                                    <?php endif; ?>
                                    <?php if($role->is_admin): ?>
                                        <i class="fas fa-crown text-warning" title="<?php echo e(trans('admin.roles.info.admin')); ?>" data-toggle="tooltip"></i>
                                    <?php endif; ?>
                                </span>
                                <span>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $role)): ?>
                                        <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="m-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $role)): ?>
                                        <a href="<?php echo e(route('admin.roles.destroy', $role)); ?>" class="m-1 <?php if($role->isDefault()): ?> disabled <?php endif; ?>" <?php if(!$role->isDefault()): ?> title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete" <?php endif; ?>><i class="fas fa-trash"></i></a>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>

            <?php if(Auth::user()->isAdmin()): ?>
                <button type="button" class="btn btn-success" id="save">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                    <span class="spinner-border spinner-border-sm btn-spinner d-none" role="status"></span>
                </button>
            <?php endif; ?>

            <a class="btn btn-primary" href="<?php echo e(route('admin.roles.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>