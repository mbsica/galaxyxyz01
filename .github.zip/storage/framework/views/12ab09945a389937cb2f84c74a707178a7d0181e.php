<?php $__env->startSection('title', trans('admin.servers.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.servers.default')); ?></h6>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.servers.change-default')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="serverSelect"><?php echo e(trans('admin.servers.default')); ?></label>
                    <select class="custom-select <?php $__errorArgs = ['server'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="serverSelect" name="server" aria-describedby="serverLabel">
                        <option value=""><?php echo e(trans('messages.none')); ?></option>
                        <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($server->id); ?>" <?php if($defaultServerId === $server->id): ?> selected <?php endif; ?>><?php echo e($server->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <small id="serverLabel" class="form-text"><?php echo e(trans('admin.servers.default-info')); ?></small>

                    <?php $__errorArgs = ['server'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.servers.title')); ?></h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                        <th scope="col"><?php echo e(trans('admin.servers.fields.address')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.status')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.type')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e($server->id); ?>

                                <?php if($server->id === $defaultServerId): ?>
                                    <i class="fas fa-certificate text-primary" title="<?php echo e(trans('admin.servers.default')); ?>" data-toggle="tooltip"></i>
                                <?php endif; ?>
                            </th>
                            <td><?php echo e($server->name); ?></td>
                            <td><?php echo e($server->fullAddress()); ?></td>
                            <td>
                                <?php if($server->isOnline()): ?>
                                    <span class="badge badge-success"><?php echo e(trans_choice('admin.servers.players', $server->getOnlinePlayers())); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-danger"><?php echo e(trans('admin.servers.offline')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(trans('admin.servers.type.'.$server->type)); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.servers.edit', $server)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.servers.destroy', $server)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <a class="btn btn-primary" href="<?php echo e(route('admin.servers.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/servers/index.blade.php ENDPATH**/ ?>