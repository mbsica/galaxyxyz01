<?php $__env->startSection('title', trans('admin.bans.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.user')); ?></th>
                        <th scope="col"><?php echo e(trans('admin.bans.fields.banned-by')); ?></th>
                        <th scope="col"><?php echo e(trans('admin.bans.fields.reason')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.date')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $bans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($ban->id); ?></th>
                            <td <?php if($ban->trashed()): ?> class="text-strikethrough" <?php endif; ?>>
                                <a href="<?php echo e(route('admin.users.edit', $ban->user)); ?>"><?php echo e($ban->user->name); ?></a></td>
                            <td>
                                <a href="<?php echo e(route('admin.users.edit', $ban->author)); ?>"><?php echo e($ban->author->name); ?></a>
                            </td>
                            <td <?php if($ban->trashed()): ?> class="text-strikethrough" <?php endif; ?>><?php echo e($ban->reason); ?></td>
                            <td><?php echo e(format_date_compact($ban->created_at)); ?></td>
                            <td>
                                <?php if(! $ban->trashed()): ?>
                                    <a href="<?php echo e(route('admin.users.bans.destroy', [$ban->user, $ban])); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                                <?php else: ?>
                                    <i><?php echo e(trans('admin.bans.removed', ['user' => $ban->remover->name ?? '???', 'date' => format_date_compact($ban->removed_at)])); ?></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <?php echo e($bans->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/bans/index.blade.php ENDPATH**/ ?>