

<?php $__env->startSection('title', trans('shop::admin.settings.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">

            <form action="<?php echo e(route('shop.admin.settings')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="currencySelect"><?php echo e(trans('shop::messages.fields.currency')); ?></label>

                    <select class="custom-select <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="currencySelect" name="currency">
                        <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($code); ?>" <?php if($currentCurrency === $code): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="useSiteMoneyCheckbox" name="use-site-money" <?php if(use_site_money()): ?> checked <?php endif; ?>>
                        <label class="custom-control-label" for="useSiteMoneyCheckbox"><?php echo e(trans('shop::admin.settings.use-site-money')); ?></label>
                    </div>
                </div>

                <div class="form-group">
                    <label for="goalInput"><?php echo e(trans('shop::messages.month-goal')); ?></label>

                    <div class="input-group">
                        <input type="number" min="0" class="form-control <?php $__errorArgs = ['goal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="goalInput" name="goal" value="<?php echo e(old('goal', $goal)); ?>">
                        <div class="input-group-append">
                            <span class="input-group-text"><?php echo e(currency_display()); ?></span>
                        </div>

                        <?php $__errorArgs = ['goal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group">
                    <label><?php echo e(trans('shop::admin.settings.commands')); ?></label>

                    <?php echo $__env->make('shop::admin.elements.commands', ['commands' => $commands], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="form-group">
                    <label for="webhookInput"><?php echo e(trans('shop::admin.settings.webhook')); ?></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['webhook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="webhookInput" name="webhook" placeholder="https://discordapp.com/api/webhooks/.../..." value="<?php echo e(old('webhook', setting('shop.webhook'))); ?>" aria-describedby="webhookInfo">

                    <?php $__errorArgs = ['webhook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <small id="webhookInfo" class="form-text"><?php echo e(trans('shop::admin.settings.webhook-info')); ?></small>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/settings.blade.php ENDPATH**/ ?>