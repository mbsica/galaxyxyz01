

<?php $__env->startSection('title', trans('messages.member')); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('elements.serverinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="h4 deco-h pt-3 pb-3"><span> <span class="text-red">Players</span> List</span></div>

<div class="row">
    <div class="col-md-3">
        <div class="card">
            <div class="card-header d-flex">
                <div class="before-icon"><i class="fas fa-users"></i></div>
                <div class="p3">Members</div>
            </div>
            <ul class="list-group">
                <a href="players"><li class="list-group-item">All Players <span class="badge badge-secondary"><?php echo e($players->count()); ?></span></li></a>
                <a href="staffs"><li class="list-group-item">Staffs <span class="badge badge-secondary"><?php echo e($players->count()); ?></span></li></a>
                <a href="donators"><li class="list-group-item">Donators <span class="badge badge-secondary"><?php echo e($players->count()); ?></span></li></a>
            </ul>
        </div>
    </div>
    <div class="col-md-9">
        <table class="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Created</th>
                <th>Last Online</th>
                <th>Status</th>
              </tr>
            </thead>
            <input class="form-control" type="text" id="userInput1" onkeyup="searchUser()" placeholder="Search for names.." title="Type in a name">
            <tbody id="myTable11">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img class="member-icon pr-2" src="<?php echo e($player->getAvatar()); ?>" alt="">
                            <?php echo e($player->name); ?>

                        </td>
                        <td>
                            <h2 class="h4 mb-0">
                                <span class="badge" style="<?php echo e($player->role->getBadgeStyle()); ?>; vertical-align: middle"><?php echo e($player->role->name); ?></span>
                            </h2>
                        </td>
                        <td><?php echo e($player->created_at->format('Y M j')); ?></td>
                        <td><?php echo e($player->last_login_at); ?></td>
                        <td>
                            <?php if($player->isOnline()): ?>
                                <div class="badge badge-success">Online</div> 
                            <?php else: ?> 
                            <div class="badge badge-danger">Offline</div> 
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
</div>
<script>
    function searchUser() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("userInput1");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable11");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0];
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/profile/list.blade.php ENDPATH**/ ?>