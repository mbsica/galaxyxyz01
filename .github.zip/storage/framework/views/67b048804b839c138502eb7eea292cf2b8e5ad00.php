

<?php $__env->startSection('title', trans('skin-api::messages.title')); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        const skinInput = document.getElementById('skin');

        skinInput.addEventListener('change', function () {
            if (!skinInput.files || !skinInput.files[0]) {
                return;
            }

            const file = skinInput.files[0];

            if (file.name !== undefined && file.name !== '') {
                document.getElementById('skinLabel').innerText = file.name;
            }

            const reader = new FileReader();

            reader.onload = function (e) {
                const preview = document.getElementById('skinPreview');
                preview.src = e.currentTarget.result;
                preview.classList.remove('d-none');
            };

            reader.readAsDataURL(skinInput.files[0]);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container content">
        <div class="card shadow mb-4">
            <div class="card-body">
                <form action="<?php echo e(route('skin-api.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <h2><?php echo e(trans('skin-api::messages.change')); ?></h2>

                    <div class="form-group">
                        <label for="skin"><?php echo e(trans('skin-api::messages.skin')); ?></label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input <?php $__errorArgs = ['skin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="skin" name="skin" accept=".png" required>
                            <label class="custom-file-label" for="skin" data-browse="<?php echo e(trans('messages.actions.browse')); ?>" id="skinLabel">
                                <?php echo e(trans('messages.actions.choose-file')); ?>

                            </label>

                            <?php $__errorArgs = ['skin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <img src="<?php echo e($skinUrl); ?>" alt="<?php echo e(trans('skin-api::messages.skin')); ?>" id="skinPreview" class="mt-3 img-fluid" style="image-rendering: pixelated; width: 350px">
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <?php echo e(trans('messages.actions.save')); ?>

                    </button>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/skin-api/resources/views/index.blade.php ENDPATH**/ ?>