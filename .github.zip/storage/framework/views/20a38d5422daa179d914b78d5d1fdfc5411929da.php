<?php $__env->startPush('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendor/clipboard/clipboard.min.js')); ?>"></script>
    <script>
        const clipboardJs = new ClipboardJS('[data-clipboard-target]');

        clipboardJs.on('success', function (e) {
            e.clearSelection();

            const oldTitle = e.trigger.dataset['originalTitle'];

            if ($.fn.tooltip) {
                e.trigger.setAttribute('data-original-title', e.trigger.dataset['copied']);
                $(e.trigger).tooltip('show');
                e.trigger.setAttribute('data-original-title', oldTitle === undefined ? '' : oldTitle);
            }
        });

        const azLinkPortInput = document.getElementById('azlinkPortInput');

        if (azLinkPortInput) {
            azLinkPortInput.addEventListener('input', function (e) {
                let port = azLinkPortInput.value;

                if (port < 1 || port > 65535) {
                    port = '25888';
                }

                document.getElementById('azLinkPortDisplay').innerText = port;
            });
        }
    </script>
    <?php if(isset($server)): ?>
        <script>
            const verifyButton = document.getElementById('verifyAzLink');
            const verifyButtonIcon = verifyButton.querySelector('.btn-spinner');

            verifyButton.addEventListener('click', function () {
                verifyButton.setAttribute('disabled', '');
                verifyButtonIcon.classList.remove('d-none');

                const formData = new FormData(document.getElementById('serverForm'));
                formData.delete('_method');

                axios.post('<?php echo e(route('admin.servers.verify-azlink', $server)); ?>', formData)
                    .then(function (json) {
                        createAlert('success', json.data.message, true);
                    }).catch(function (error) {
                    createAlert('danger', error.response.data.message ? error.response.data.message : error, true)
                }).finally(function () {
                    verifyButton.removeAttribute('disabled');
                    verifyButtonIcon.classList.add('d-none');
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo csrf_field(); ?>

<div class="form-row">
    <div class="form-group col-md-6">
        <label for="nameInput"><?php echo e(trans('messages.fields.name')); ?></label>
        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nameInput" name="name" value="<?php echo e(old('name', $server->name ?? '')); ?>" required>

        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-6">
        <label for="typeSelect"><?php echo e(trans('messages.fields.type')); ?></label>
        <select class="custom-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="typeSelect" name="type" required data-toggle-select="server-type">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type); ?>" <?php if($type === old('type', $server->type ?? '')): ?> selected <?php endif; ?>><?php echo e(trans('admin.servers.type.'.$type)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-row">
    <div class="form-group col-md-8">
        <label for="addressInput"><?php echo e(trans('admin.servers.fields.address')); ?></label>
        <input type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="addressInput" name="address" value="<?php echo e(old('address', $server->address ?? '')); ?>" required>

        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group col-md-4">
        <label for="portInput"><?php echo e(trans('admin.servers.fields.port')); ?></label>
        <input type="number" min="1" max="65535" class="form-control <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="portInput" name="port" value="<?php echo e(old('port', $server->port ?? '')); ?>">

        <?php $__errorArgs = ['port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div data-server-type="mc-ping" class="form-group d-none">
    <div class="alert alert-info" role="alert">
        <i class="fas fa-info-circle"></i> <?php echo e(trans('admin.servers.ping-no-commands')); ?>

    </div>
</div>

<div data-server-type="source-query source-rcon" class="d-none">
    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="querySourcePortInput"><?php echo e(trans('admin.servers.fields.query-port')); ?></label>
            <input type="number" min="1" max="65535" class="form-control <?php $__errorArgs = ['query-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="querySourcePortInput" name="query-port" value="<?php echo e(old('query-port', $server->data['query-port'] ?? '')); ?>" aria-describedby="queryPortInfo">

            <?php $__errorArgs = ['query-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <small id="queryPortInfo" class="form-text"><?php echo e(trans('admin.servers.query-port-info')); ?></small>
        </div>
    </div>
</div>

<div data-server-type="source-query" class="form-group d-none">
    <div class="alert alert-info" role="alert">
        <i class="fas fa-info-circle"></i> <?php echo e(trans('admin.servers.query-no-commands')); ?>

    </div>
</div>

<div data-server-type="mc-rcon source-rcon rust-rcon" class="d-none">
    <div class="form-row">
        <div class="form-group col-md-8">
            <label for="rconPasswordInput"><?php echo e(trans('admin.servers.fields.rcon-password')); ?></label>

            <div class="input-group">
                <input type="password" class="form-control <?php $__errorArgs = ['rcon-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rconPasswordInput" name="rcon-password" value="<?php echo e(old('rcon-password', ! empty($server->data['rcon-password']) ? decrypt($server->data['rcon-password'], false) : '')); ?>">
                <div class="input-group-append">
                    <button type="button" class="btn btn-outline-primary" data-password-toggle="rconPasswordInput">
                        <i class="fas fa-eye-slash"></i>
                    </button>
                </div>

                <?php $__errorArgs = ['rcon-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group col-md-4">
            <label for="rconPortInput"><?php echo e(trans('admin.servers.fields.rcon-port')); ?></label>
            <input type="number" min="1" max="65535" class="form-control <?php $__errorArgs = ['rcon-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rconPortInput" name="rcon-port" value="<?php echo e(old('rcon-port', $server->data['rcon-port'] ?? '')); ?>" aria-describedby="rconPortInfo">

            <?php $__errorArgs = ['rcon-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <small id="rconPortInfo" class="form-text"><?php echo e(trans('admin.servers.query-port-info')); ?></small>
        </div>
    </div>
</div>

<div data-server-type="mc-azlink" class="d-none">
    <div class="form-group custom-control custom-switch">
        <input type="checkbox" class="custom-control-input" id="hasPingSwitch" name="azlink-ping" data-toggle="collapse" data-target="#hasPingGroup" <?php if(isset($server) && ($server->data['azlink-ping'] ?? false)): ?> checked <?php endif; ?> aria-describedby="pingInfo">
        <label class="custom-control-label" for="hasPingSwitch"><?php echo e(trans('admin.servers.azlink.enable-ping')); ?></label>

        <small class="form-text" id="pingInfo"><?php echo e(trans('admin.servers.azlink.ping-info')); ?></small>
    </div>

    <div id="hasPingGroup" class="<?php if(isset($server) && ($server->data['azlink-ping'] ?? false)): ?> show <?php else: ?> collapse <?php endif; ?>">
        <div class="form-group custom-control custom-switch">
            <input type="checkbox" class="custom-control-input" id="customPortSwitch" name="azlink-custom-port" data-toggle="collapse" data-target="#customPortGroup" <?php if(isset($server->data['azlink-port'])): ?> checked <?php endif; ?>>
            <label class="custom-control-label" for="customPortSwitch"><?php echo e(trans('admin.servers.azlink.custom-port')); ?></label>
        </div>

        <div id="customPortGroup" class="<?php if(isset($server->data['azlink-port'])): ?> show <?php else: ?> collapse <?php endif; ?>">
            <div class="card card-body mb-3">
                <div class="form-group">
                    <label for="azlinkPortInput"><?php echo e(trans('admin.servers.fields.azlink-port')); ?></label>
                    <input type="number" min="1" max="65535" class="form-control <?php $__errorArgs = ['azlink-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="azlinkPortInput" name="azlink-port" value="<?php echo e(old('azlink-port', $server->data['azlink-port'] ?? '')); ?>" placeholder="25588">

                    <?php $__errorArgs = ['azlink-port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="alert alert-info mb-0" role="alert">
                    <i class="fas fa-info-circle"></i>
                    <?php echo e(trans('admin.servers.azlink.port-info')); ?>

                    <code id="portCommand" class="cursor-copy" title="<?php echo e(trans('messages.actions.copy')); ?>" data-copied="<?php echo e(trans('messages.copied')); ?>" data-toggle="tooltip" data-clipboard-target="#portCommand">/azlink port
                        <span id="azLinkPortDisplay"><?php echo e($server->data['azlink-port'] ?? '25588'); ?></span></code>
                </div>
            </div>
        </div>

        <?php if(isset($server)): ?>
            <button type="button" class="btn btn-success mb-4" id="verifyAzLink">
                <i class="fas fa-check"></i> <?php echo e(trans('admin.servers.actions.verify-connection')); ?>

                <span class="spinner-border spinner-border-sm btn-spinner d-none" role="status"></span>
            </button>
        <?php endif; ?>
    </div>

    <?php if(isset($server)): ?>
        <div class="form-group">
            <?php if($server->isOnline()): ?>
                <div class="alert alert-info" role="alert">
                    <i class="fas fa-info-circle"></i>
                    <?php echo e(trans('admin.servers.azlink.link-info')); ?>

                    <code id="linkCommand" class="cursor-copy" title="<?php echo e(trans('messages.actions.copy')); ?>" data-copied="<?php echo e(trans('messages.copied')); ?>" data-toggle="tooltip" data-clipboard-target="#linkCommand"><?php echo e($server->getLinkCommand()); ?></code>
                    .
                </div>
            <?php else: ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(trans('admin.servers.azlink.link')); ?>

                    <ol class="mb-0">
                        <li><?php echo app('translator')->get('admin.servers.azlink.link-1'); ?></li>
                        <li><?php echo e(trans('admin.servers.azlink.link-2')); ?></li>
                        <li>
                            <?php echo e(trans('admin.servers.azlink.link-3')); ?>

                            <code id="linkCommand" class="cursor-copy" title="<?php echo e(trans('messages.actions.copy')); ?>" data-copied="<?php echo e(trans('messages.copied')); ?>" data-toggle="tooltip" data-clipboard-target="#linkCommand"><?php echo e($server->getLinkCommand()); ?></code>
                            .
                        </li>
                    </ol>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <button type="submit" name="redirect" value="edit" class="btn btn-success mb-2">
            <i class="fas fa-arrow-right"></i> <?php echo e(trans('messages.actions.continue')); ?>

        </button>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/servers/_form.blade.php ENDPATH**/ ?>