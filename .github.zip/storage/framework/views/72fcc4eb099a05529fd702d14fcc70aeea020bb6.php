<?php $__env->startSection('title', trans('admin.roles.title-edit', ['role' => $role->name])); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.roles.update', $role)); ?>" method="POST">
                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('admin.roles._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>

                <?php if(! $role->isDefault()): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $role)): ?>
                        <a href="<?php echo e(route('admin.roles.destroy', $role)); ?>" class="btn btn-danger" data-confirm="delete">
                            <i class="fas fa-trash"></i> <?php echo e(trans('messages.actions.delete')); ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>