<?php $__env->startSection('title', trans('admin.dashboard.title')); ?>

<?php $__env->startSection('content'); ?>
    <?php if(! $secure): ?>
        <div id="notHttpsAlert" class="alert alert-warning shadow-sm" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?php echo e(trans('admin.dashboard.https-warning')); ?>

        </div>
        <div id="proxyAlert" class="alert alert-info shadow-sm d-none" role="alert">
            <i class="fas fa-info-circle"></i> <?php echo e(trans('admin.dashboard.proxy-warning')); ?>

        </div>
    <?php endif; ?>

    <?php if(config('mail.default') === 'array' && ! oauth_login()): ?>
        <div class="alert alert-warning shadow-sm" role="alert">
            <i class="fas fa-info-circle"></i> <?php echo app('translator')->get('admin.dashboard.emails-disabled', ['url' => route('admin.settings.mail')]); ?>
        </div>
    <?php endif; ?>

    <?php if($newVersion !== null): ?>
        <div class="alert alert-info shadow-sm" role="alert">
            <i class="fas fa-plus"></i> <?php echo e(trans('admin.dashboard.new-update', ['version' => $newVersion])); ?>.
            <a href="<?php echo e(route('admin.update.index')); ?>"><?php echo e(trans('admin.update.actions.install')); ?></a>.
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $apiAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alertLevel => $alertMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-<?php echo e($alertLevel); ?> shadow-sm" role="alert">
            <?php echo $alertMessage; ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Content Row -->
    <div class="row">

        <!-- Users card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e(trans('admin.dashboard.users')); ?></div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($userCount); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Posts card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e(trans('admin.dashboard.posts')); ?></div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($postCount); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-newspaper fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pages card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e(trans('admin.dashboard.pages')); ?></div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($pageCount); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pages card -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e(trans('admin.dashboard.images')); ?></div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($imageCount); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-image fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $__currentLoopData = $cards ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-<?php echo e($card['color']); ?> shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e(trans($card['name'])); ?></div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($card['value']); ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="<?php echo e($card['icon']); ?> fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.dashboard.recent-users')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="tab-content mb-3">
                        <div class="tab-pane fade show active" id="monthlyChart" role="tabpanel" aria-labelledby="monthlyChartTab">
                            <div class="chart-area">
                                <canvas id="newUsersPerMonthsChart"></canvas>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="dailyChart" role="tabpanel" aria-labelledby="dailyChartTab">
                            <div class="chart-area">
                                <canvas id="newUsersPerDaysChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link active" id="monthlyChartTab" data-toggle="pill" href="#monthlyChart" role="tab" aria-controls="monthlyChart" aria-selected="true">
                                <?php echo e(trans('messages.range.months')); ?>

                            </a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" id="dailyChartTab" data-toggle="pill" href="#dailyChart" role="tab" aria-controls="dailyChart" aria-selected="false">
                                <?php echo e(trans('messages.range.days')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('admin.dashboard.active-users')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="activeUsersChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-1">
                            <i class="fas fa-circle text-primary"></i> <?php echo e(now()->subDay()->longAbsoluteDiffForHumans()); ?>

                        </span>
                        <span class="mr-1">
                            <i class="fas fa-circle text-success"></i> <?php echo e(now()->subWeek()->longAbsoluteDiffForHumans()); ?>

                        </span>
                        <span class="mr-1">
                            <i class="fas fa-circle text-info"></i> <?php echo e(now()->subMonth()->longAbsoluteDiffForHumans()); ?>

                        </span>
                        <span class="mr-1">
                            <i class="fas fa-circle text-warning"></i> + <?php echo e(now()->subMonth()->longAbsoluteDiffForHumans()); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/charts.js')); ?>"></script>
    <script>
        createLineChart('newUsersPerMonthsChart', <?php echo json_encode($newUsersPerMonths, 15, 512) ?>, '<?php echo e(trans('admin.dashboard.recent-users')); ?>');
        createLineChart('newUsersPerDaysChart', <?php echo json_encode($newUsersPerDays, 15, 512) ?>, '<?php echo e(trans('admin.dashboard.recent-users')); ?>');
        createPieChart('activeUsersChart', <?php echo json_encode($activeUsers, 15, 512) ?>);
    </script>

    <?php if(! $secure): ?>
        <script>
            // When using a proxy, if the traffic is encrypted only between the
            // proxy and the web server, the warn can be show even if the user use https
            // (like with Cloudflare flexible encryption). In this case we just
            // hide the warning and display an info text.
            if (window.location.protocol === 'https:') {
                document.getElementById('notHttpsAlert').classList.add('d-none');
                document.getElementById('proxyAlert').classList.remove('d-none');
            }
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>