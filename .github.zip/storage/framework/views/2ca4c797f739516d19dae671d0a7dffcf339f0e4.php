<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('vendor/flatpickr/css/flatpickr.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendor/flatpickr/js/flatpickr.min.js')); ?>"></script>
    <script>
        flatpickr('.date-picker', {
            time_24hr: true,
            enableTime: true,
            enableSeconds: true,
            minuteIncrement: 1
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/elements/date-picker.blade.php ENDPATH**/ ?>