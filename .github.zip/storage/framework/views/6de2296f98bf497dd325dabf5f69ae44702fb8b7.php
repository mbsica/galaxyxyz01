

<?php $__env->startSection('title', trans('shop::admin.gateways.title')); ?>

<?php $__env->startSection('content'); ?>
    <?php if(! $gateways->isEmpty()): ?>
        <div class="card shadow mb-4">
            <div class="card-header">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('shop::admin.gateways.subtitle-current')); ?></h6>
            </div>

            <div class="card-body">
                <div class="row">

                    <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="card shadow-sm mb-3">
                                <div class="card-header"><?php echo e($gateway->name); ?></div>
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <img src="<?php echo e($gateway->paymentMethod()->image()); ?>" style="max-height: 45px" class="img-fluid" alt="<?php echo e($gateway->name); ?>">
                                    </div>

                                    <a href="<?php echo e(route('shop.admin.gateways.edit', $gateway)); ?>" class="btn btn-primary">
                                        <i class="fas fa-edit"></i> <?php echo e(trans('messages.actions.edit')); ?>

                                    </a>
                                    <a href="<?php echo e(route('shop.admin.gateways.destroy', $gateway)); ?>" class="btn btn-danger" data-confirm="delete">
                                        <i class="fas fa-trash"></i> <?php echo e(trans('messages.actions.delete')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if(! $paymentMethods->isEmpty()): ?>
        <div class="card shadow mb-4">
            <div class="card-header">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo e(trans('shop::admin.gateways.subtitle-add')); ?></h6>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="typeSelect"><?php echo e(trans('messages.fields.type')); ?></label>
                    <select class="custom-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="typeSelect" name="type" required>
                        <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(route('shop.admin.gateways.create', $paymentMethod)); ?>"><?php echo e($paymentMethod); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <a href="#" onclick="this.href = document.getElementById('typeSelect').value" class="btn btn-primary">
                    <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

                </a>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\plugins/shop/resources/views/admin/gateways/index.blade.php ENDPATH**/ ?>