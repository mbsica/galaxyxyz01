<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
    <style>
        .bootstrap-select {
            width: 100%!important;
            display: block!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js" defer></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('footer-scripts'); ?>
    <script>
        document.querySelectorAll('select[multiple]').forEach(function (el) {
            el.classList.remove('custom-select', 'form-control');
            el.classList.add('selectpicker');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /home/galaowmw/galaxy/plugins/shop/resources/views/admin/elements/select.blade.php ENDPATH**/ ?>