<?php $__env->startSection('title', trans('admin.pages.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.title')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.slug')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.enabled')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($page->id); ?></th>
                            <td><?php echo e($page->title); ?></td>
                            <td>
                                <a href="<?php echo e(route('pages.show', $page)); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo e($page->slug); ?>

                                </a>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo e($page->is_enabled ? 'success' : 'danger'); ?>">
                                    <?php echo e(trans_bool($page->is_enabled)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.pages.edit', $page)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.pages.destroy', $page)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <?php echo e($pages->links()); ?>


            <a class="btn btn-primary" href="<?php echo e(route('admin.pages.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>