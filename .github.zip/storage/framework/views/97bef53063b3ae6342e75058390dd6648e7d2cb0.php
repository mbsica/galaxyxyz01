

<?php $__env->startSection('title', trans('vote::admin.sites.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.url')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.enabled')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($site->id); ?></th>
                            <td><?php echo e($site->name); ?></td>
                            <td><?php echo e($site->url); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($site->is_enabled ? 'success' : 'danger'); ?>">
                                    <?php echo e(trans_bool($site->is_enabled)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('vote.admin.sites.edit', $site)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('vote.admin.sites.destroy', $site)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <a class="btn btn-primary" href="<?php echo e(route('vote.admin.sites.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/plugins/vote/resources/views/admin/sites/index.blade.php ENDPATH**/ ?>