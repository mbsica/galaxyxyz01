<?php $__env->startSection('title', trans('admin.posts.title-edit', ['post' => $post->title])); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.posts.update', $post)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('admin.elements.editor', ['imagesUploadUrl' => route('admin.posts.attachments.store', $post)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('admin.posts._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?php echo e(trans('messages.actions.save')); ?>

                </button>
                <a href="<?php echo e(route('admin.posts.destroy', $post)); ?>" class="btn btn-danger" data-confirm="delete">
                    <i class="fas fa-trash"></i> <?php echo e(trans('messages.actions.delete')); ?>

                </a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\galaxy\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>