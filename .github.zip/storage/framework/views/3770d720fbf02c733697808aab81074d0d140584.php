<?php $__env->startSection('title', trans('admin.images.title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo e(trans('messages.fields.image')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.name')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.file')); ?></th>
                        <th scope="col"><?php echo e(trans('messages.fields.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($image->id); ?></th>
                            <td>
                                <img src="<?php echo e($image->url()); ?>" class="img-small rounded" alt="<?php echo e($image->name); ?>">
                            </td>
                            <td><?php echo e($image->name); ?></td>
                            <td>
                                <a href="<?php echo e($image->url()); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo e($image->file); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.images.edit', $image)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.edit')); ?>" data-toggle="tooltip"><i class="fas fa-edit"></i></a>
                                <a href="<?php echo e(route('admin.images.destroy', $image)); ?>" class="mx-1" title="<?php echo e(trans('messages.actions.delete')); ?>" data-toggle="tooltip" data-confirm="delete"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <?php echo e($images->links()); ?>


            <a class="btn btn-primary" href="<?php echo e(route('admin.images.create')); ?>">
                <i class="fas fa-upload"></i> <?php echo e(trans('messages.actions.add')); ?>

            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/galaowmw/galaxy/resources/views/admin/images/index.blade.php ENDPATH**/ ?>